import express from 'express';
import http from 'http';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { Server } from 'socket.io';
import { initDb, saveGameRecordToDb, getGameHistoryFromDb } from './src/db';

// ============================================================================
// GEOMETRIC CARD THEMES & EMOJIS (Must match App.tsx)
// ============================================================================
const THEMES = {
  animals: [
    { emoji: '🦊', label: 'FOX', color: 'bg-gradient-to-br from-amber-400 to-orange-500 border-amber-300 shadow-amber-200' },
    { emoji: '🦁', label: 'LION', color: 'bg-gradient-to-br from-orange-400 to-amber-500 border-orange-300 shadow-orange-200' },
    { emoji: '🐼', label: 'PANDA', color: 'bg-gradient-to-br from-slate-600 to-slate-800 border-slate-500 shadow-slate-200' },
    { emoji: '🐸', label: 'FROG', color: 'bg-gradient-to-br from-emerald-400 to-green-600 border-emerald-300 shadow-emerald-200' },
    { emoji: '🐯', label: 'TIGER', color: 'bg-gradient-to-br from-yellow-400 to-orange-500 border-yellow-300 shadow-yellow-200' },
    { emoji: '🐻', label: 'BEAR', color: 'bg-gradient-to-br from-amber-700 to-amber-900 border-amber-600 shadow-amber-300' },
    { emoji: '🐨', label: 'KOALA', color: 'bg-gradient-to-br from-zinc-400 to-zinc-600 border-zinc-300 shadow-zinc-200' },
    { emoji: '🐙', label: 'OCTOPUS', color: 'bg-gradient-to-br from-rose-400 to-pink-600 border-rose-300 shadow-rose-200' },
    { emoji: '🦄', label: 'UNICORN', color: 'bg-gradient-to-br from-fuchsia-400 to-violet-600 border-fuchsia-300 shadow-fuchsia-200' },
    { emoji: '🐝', label: 'HONEYBEE', color: 'bg-gradient-to-br from-amber-300 to-yellow-500 border-amber-200 shadow-amber-100' },
    { emoji: '🐢', label: 'TURTLE', color: 'bg-gradient-to-br from-teal-400 to-emerald-600 border-teal-300 shadow-teal-200' },
    { emoji: '🐬', label: 'DOLPHIN', color: 'bg-gradient-to-br from-cyan-400 to-blue-600 border-cyan-300 shadow-cyan-200' },
  ],
  food: [
    { emoji: '🍕', label: 'PIZZA', color: 'bg-gradient-to-br from-rose-500 to-red-600 border-red-300 shadow-red-200' },
    { emoji: '🍔', label: 'BURGER', color: 'bg-gradient-to-br from-amber-400 to-orange-500 border-amber-300 shadow-amber-200' },
    { emoji: '🍟', label: 'FRIES', color: 'bg-gradient-to-br from-yellow-300 to-amber-500 border-yellow-200 shadow-yellow-100' },
    { emoji: '🍩', label: 'DONUT', color: 'bg-gradient-to-br from-pink-400 to-fuchsia-600 border-fuchsia-300 shadow-fuchsia-200' },
    { emoji: '🍓', label: 'BERRY', color: 'bg-gradient-to-br from-rose-400 to-pink-500 border-rose-300 shadow-rose-200' },
    { emoji: '🥑', label: 'AVOCADO', color: 'bg-gradient-to-br from-emerald-400 to-green-600 border-green-300 shadow-green-200' },
    { emoji: '🍦', label: 'ICE CREAM', color: 'bg-gradient-to-br from-sky-300 to-indigo-400 border-sky-200 shadow-sky-100' },
    { emoji: '🍣', label: 'SUSHI', color: 'bg-gradient-to-br from-slate-500 to-neutral-700 border-neutral-400 shadow-neutral-200' },
    { emoji: '🌮', label: 'TACO', color: 'bg-gradient-to-br from-orange-400 to-amber-500 border-orange-300 shadow-orange-200' },
    { emoji: '🍉', label: 'MELON', color: 'bg-gradient-to-br from-rose-400 to-emerald-500 border-rose-300 shadow-rose-200' },
    { emoji: '🍪', label: 'COOKIE', color: 'bg-gradient-to-br from-amber-600 to-amber-800 border-amber-500 shadow-amber-200' },
    { emoji: '🥞', label: 'PANCAKES', color: 'bg-gradient-to-br from-yellow-400 to-amber-600 border-yellow-300 shadow-yellow-200' },
  ],
  space: [
    { emoji: '🚀', label: 'ROCKET', color: 'bg-gradient-to-br from-sky-400 to-indigo-600 border-sky-300 shadow-sky-200' },
    { emoji: '🌙', label: 'MOON', color: 'bg-gradient-to-br from-slate-300 to-slate-500 border-slate-200 shadow-slate-100' },
    { emoji: '🪐', label: 'SATURN', color: 'bg-gradient-to-br from-amber-400 to-yellow-600 border-amber-300 shadow-amber-200' },
    { emoji: '⭐', label: 'STAR', color: 'bg-gradient-to-br from-yellow-300 to-orange-400 border-yellow-200 shadow-yellow-100' },
    { emoji: '🛸', label: 'UFO', color: 'bg-gradient-to-br from-indigo-400 to-purple-600 border-indigo-300 shadow-indigo-200' },
    { emoji: '🌍', label: 'EARTH', color: 'bg-gradient-to-br from-blue-400 to-emerald-600 border-blue-300 shadow-blue-200' },
    { emoji: '☄️', label: 'COMET', color: 'bg-gradient-to-br from-slate-400 to-neutral-600 border-slate-300 shadow-slate-200' },
    { emoji: '☀️', label: 'SUN', color: 'bg-gradient-to-br from-orange-400 to-red-500 border-orange-300 shadow-orange-200' },
    { emoji: '👾', label: 'ALIEN', color: 'bg-gradient-to-br from-purple-400 to-violet-600 border-purple-300 shadow-purple-200' },
    { emoji: '🔭', label: 'TELESCOPE', color: 'bg-gradient-to-br from-zinc-500 to-slate-700 border-zinc-400 shadow-zinc-200' },
    { emoji: '🌌', label: 'GALAXY', color: 'bg-gradient-to-br from-violet-500 to-fuchsia-700 border-violet-400 shadow-violet-200' },
    { emoji: '🛰️', label: 'SATELLITE', color: 'bg-gradient-to-br from-gray-400 to-slate-600 border-gray-300 shadow-gray-200' },
  ],
  games: [
    { emoji: '⚽', label: 'SOCCER', color: 'bg-gradient-to-br from-neutral-400 to-neutral-700 border-neutral-300 shadow-neutral-200' },
    { emoji: '🏀', label: 'HOOPS', color: 'bg-gradient-to-br from-orange-400 to-red-500 border-orange-300 shadow-orange-200' },
    { emoji: '🎮', label: 'CONSOLE', color: 'bg-gradient-to-br from-indigo-400 to-indigo-600 border-indigo-300 shadow-indigo-200' },
    { emoji: '🎲', label: 'DICE', color: 'bg-gradient-to-br from-red-400 to-rose-600 border-red-300 shadow-red-200' },
    { emoji: '🎯', label: 'DART', color: 'bg-gradient-to-br from-sky-400 to-blue-600 border-sky-300 shadow-sky-200' },
    { emoji: '🏎️', label: 'RACECAR', color: 'bg-gradient-to-br from-rose-400 to-red-600 border-rose-300 shadow-rose-200' },
    { emoji: '🏆', label: 'TROPHY', color: 'bg-gradient-to-br from-yellow-300 to-amber-500 border-yellow-200 shadow-yellow-100' },
    { emoji: '🎨', label: 'PALETTE', color: 'bg-gradient-to-br from-emerald-400 to-teal-600 border-emerald-300 shadow-emerald-200' },
    { emoji: '🧩', label: 'PUZZLE', color: 'bg-gradient-to-br from-teal-400 to-cyan-600 border-teal-300 shadow-teal-200' },
    { emoji: '🎳', label: 'BOWLING', color: 'bg-gradient-to-br from-slate-400 to-slate-600 border-slate-300 shadow-slate-200' },
    { emoji: '♟️', label: 'CHESS', color: 'bg-gradient-to-br from-stone-400 to-stone-700 border-stone-400 shadow-stone-200' },
    { emoji: '🎸', label: 'GUITAR', color: 'bg-gradient-to-br from-red-400 to-rose-600 border-red-300 shadow-red-200' },
  ]
};

type ThemeName = keyof typeof THEMES;

interface Card {
  id: string;
  value: string;
  color: string;
  label: string;
  isFlipped: boolean;
  isMatched: boolean;
}

interface Player {
  id: string;
  name: string;
  isHost: boolean;
  score: number;
  streak: number;
  isConnected: boolean;
}

interface ChatMessage {
  id: string;
  playerId: string;
  name: string;
  text: string;
  timestamp: number;
}

interface Lobby {
  code: string;
  difficulty: string;
  theme: ThemeName;
  players: Player[];
  gameStarted: boolean;
  gameWon: boolean;
  cards: Card[];
  activeTurnPlayerId: string;
  selectedCardIndices: number[];
  winnerId: string | null;
  isEvaluating: boolean;
  messages: ChatMessage[];
  secondsElapsed: number;
  timerIntervalId?: NodeJS.Timeout;
}

// Global state for active lobbies
const lobbies = new Map<string, Lobby>();
// Track connection mappings with socket IDs
const socketPlayerMap = new Map<string, { playerId: string; roomCode: string }>();

const PORT = 3000;

async function startServer() {
  // Initialize SQLite database
  await initDb();

  const app = express();
  const server = http.createServer(app);
  
  // Set up Socket.io server
  const io = new Server(server, {
    cors: {
      origin: "*",
      methods: ["GET", "POST"]
    }
  });

  // REST API Health and history endpoints
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', activeLobbies: lobbies.size });
  });

  app.get('/api/history', async (req, res) => {
    const history = await getGameHistoryFromDb();
    res.json(history);
  });

  app.post('/api/history', express.json(), async (req, res) => {
    try {
      const { id, mode, difficulty, theme, durationSeconds, completedAt, players } = req.body;
      await saveGameRecordToDb(id, mode, difficulty, theme, durationSeconds, completedAt, players);
      res.json({ status: 'success' });
    } catch (err) {
      res.status(500).json({ error: 'Failed to save record' });
    }
  });

  // Helper to generate a room code
  function generateRoomCode(): string {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // Readable alphanumeric
    let code = '';
    for (let i = 0; i < 4; i++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return code;
  }

  // Broadcast helper using Socket.io rooms
  function broadcast(roomCode: string, payload: any) {
    const room = lobbies.get(roomCode);
    if (!room) return;
    io.to(roomCode).emit('message', payload);
  }

  // WebSocket Server logic
  io.on('connection', (socket) => {
    const randomPlayerId = 'p_' + Math.random().toString(36).substr(2, 9);
    socketPlayerMap.set(socket.id, { playerId: randomPlayerId, roomCode: '' });

    socket.on('message', (payload: any) => {
      try {
        const connInfo = socketPlayerMap.get(socket.id);
        if (!connInfo) return;

        const { type } = payload;

        switch (type) {
          case 'create_lobby': {
            const { name, difficulty, theme } = payload;
            const code = generateRoomCode();
            
            const newLobby: Lobby = {
              code,
              difficulty: difficulty || 'medium',
              theme: (theme as ThemeName) || 'animals',
              players: [
                {
                  id: randomPlayerId,
                  name: name || 'Host',
                  isHost: true,
                  score: 0,
                  streak: 0,
                  isConnected: true,
                },
              ],
              gameStarted: false,
              gameWon: false,
              cards: [],
              activeTurnPlayerId: randomPlayerId,
              selectedCardIndices: [],
              winnerId: null,
              isEvaluating: false,
              messages: [],
              secondsElapsed: 0,
            };

            lobbies.set(code, newLobby);
            connInfo.roomCode = code;
            socket.join(code);

            socket.emit('message', {
              type: 'lobby_created',
              code,
              lobby: { ...newLobby, messages: newLobby.messages.slice(-15) },
              playerId: randomPlayerId,
            });
            break;
          }

          case 'join_lobby': {
            const { code, name } = payload;
            const targetCode = String(code).toUpperCase().trim();
            const lobby = lobbies.get(targetCode);

            if (!lobby) {
              socket.emit('message', { type: 'error', message: 'Lobby not found.' });
              return;
            }

            if (lobby.gameStarted) {
              socket.emit('message', { type: 'error', message: 'Game already in progress.' });
              return;
            }

            if (lobby.players.length >= 10) {
              socket.emit('message', { type: 'error', message: 'Lobby is full.' });
              return;
            }

            // Join the lobby
            const newPlayer: Player = {
              id: randomPlayerId,
              name: name || `Player ${lobby.players.length + 1}`,
              isHost: false,
              score: 0,
              streak: 0,
              isConnected: true,
            };

            lobby.players.push(newPlayer);
            connInfo.roomCode = targetCode;
            socket.join(targetCode);

            socket.emit('message', {
              type: 'lobby_joined',
              code: targetCode,
              lobby: { ...lobby, messages: lobby.messages.slice(-15) },
              playerId: randomPlayerId,
            });

            // Notify everyone in the lobby
            broadcast(targetCode, {
              type: 'player_joined',
              lobby: { ...lobby, messages: lobby.messages.slice(-15) },
            });
            break;
          }

          case 'start_game': {
            const { code } = payload;
            const lobby = lobbies.get(code);
            if (!lobby) return;

            // Enforce admin/host only
            const player = lobby.players.find((p) => p.id === randomPlayerId);
            if (!player || !player.isHost) {
              socket.emit('message', { type: 'error', message: 'Only the host can start the game.' });
              return;
            }

            // Require at least 2 players
            if (lobby.players.length < 2) {
              socket.emit('message', { type: 'error', message: 'At least 2 players are required to start the match. Please wait for a real player to join!' });
              return;
            }

            // Create cards
            let numPairs = 8; // default medium (16 cards)
            if (lobby.difficulty === 'easy') numPairs = 6;
            else if (lobby.difficulty === 'hard') numPairs = 10;

            const selectedThemeList = THEMES[lobby.theme].slice(0, numPairs);
            const paired = [...selectedThemeList, ...selectedThemeList];

            const cardObjects: Card[] = paired.map((item, index) => ({
              id: `${item.label}-${index}`,
              value: item.emoji,
              color: item.color,
              label: item.label,
              isFlipped: false,
              isMatched: false,
            }));

            // Fisher-Yates Shuffle on Server
            for (let i = cardObjects.length - 1; i > 0; i--) {
              const j = Math.floor(Math.random() * (i + 1));
              const temp = cardObjects[i];
              cardObjects[i] = cardObjects[j];
              cardObjects[j] = temp;
            }

            lobby.cards = cardObjects;
            lobby.gameStarted = true;
            lobby.gameWon = false;
            lobby.selectedCardIndices = [];
            lobby.isEvaluating = false;
            lobby.winnerId = null;
            lobby.secondsElapsed = 0;

            // Reset scores
            lobby.players.forEach((p) => {
              p.score = 1000;
              p.streak = 0;
            });

            lobby.activeTurnPlayerId = lobby.players[0]?.id || randomPlayerId;

            // Start room server timer interval
            if (lobby.timerIntervalId) {
              clearInterval(lobby.timerIntervalId);
            }
            lobby.timerIntervalId = setInterval(() => {
              const activeRoom = lobbies.get(code);
              if (activeRoom && activeRoom.gameStarted && !activeRoom.gameWon) {
                activeRoom.secondsElapsed += 1;
                activeRoom.players.forEach((p) => {
                  p.score = Math.max(0, p.score - 1); // Decay score
                });
                broadcast(code, {
                  type: 'time_tick',
                  secondsElapsed: activeRoom.secondsElapsed,
                  players: activeRoom.players,
                });
              } else {
                if (lobby.timerIntervalId) clearInterval(lobby.timerIntervalId);
              }
            }, 1000);

            broadcast(code, {
              type: 'game_started',
              lobby: { ...lobby, messages: lobby.messages.slice(-15) },
            });
            break;
          }

          case 'flip_card': {
            const { code, index } = payload;
            const lobby = lobbies.get(code);
            if (!lobby || !lobby.gameStarted || lobby.gameWon || lobby.isEvaluating) return;

            // Validate turn
            if (lobby.activeTurnPlayerId !== randomPlayerId) {
              socket.emit('message', { type: 'error', message: "It's not your turn!" });
              return;
            }

            // Validate card flip
            const card = lobby.cards[index];
            if (!card || card.isFlipped || card.isMatched) return;

            // Perform flip
            card.isFlipped = true;
            lobby.selectedCardIndices.push(index);

            // Broadcast immediate flip
            broadcast(code, {
              type: 'card_flipped_update',
              cards: lobby.cards,
              selectedIndices: lobby.selectedCardIndices,
            });

            // Evaluation if 2 cards are flipped
            if (lobby.selectedCardIndices.length === 2) {
              lobby.isEvaluating = true;
              const [firstIdx, secondIdx] = lobby.selectedCardIndices;
              const activePlayer = lobby.players.find((p) => p.id === randomPlayerId);

              if (lobby.cards[firstIdx].value === lobby.cards[secondIdx].value) {
                // MATCH SCENARIO
                lobby.cards[firstIdx].isMatched = true;
                lobby.cards[firstIdx].isFlipped = false;
                lobby.cards[secondIdx].isMatched = true;
                lobby.cards[secondIdx].isFlipped = false;

                if (activePlayer) {
                  activePlayer.streak += 1;
                  const bonus = (activePlayer.streak - 1) * 50;
                  activePlayer.score += 200 + bonus;
                }

                lobby.selectedCardIndices = [];
                lobby.isEvaluating = false;

                // Check win condition
                const allMatched = lobby.cards.every((c) => c.isMatched);
                if (allMatched) {
                  lobby.gameWon = true;
                  if (lobby.timerIntervalId) {
                    clearInterval(lobby.timerIntervalId);
                  }
                  // Find player with highest score
                  let topScore = -1;
                  let winnerId = randomPlayerId;
                  lobby.players.forEach((p) => {
                    if (p.score > topScore) {
                      topScore = p.score;
                      winnerId = p.id;
                    }
                  });
                  lobby.winnerId = winnerId;

                  // Save game record to SQLite DB
                  saveGameRecordToDb(
                    `game_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
                    'multiplayer',
                    lobby.difficulty,
                    lobby.theme,
                    lobby.secondsElapsed,
                    new Date().toISOString(),
                    lobby.players.map((p) => ({
                      name: p.name,
                      score: p.score,
                      isWinner: p.id === lobby.winnerId
                    }))
                  );
                }

                broadcast(code, {
                  type: 'turn_result',
                  matched: true,
                  cards: lobby.cards,
                  players: lobby.players,
                  nextTurn: lobby.activeTurnPlayerId, // Keeps turn on match
                  gameWon: lobby.gameWon,
                  winnerId: lobby.winnerId,
                });
              } else {
                // MISMATCH SCENARIO
                if (activePlayer) {
                  activePlayer.streak = 0;
                  activePlayer.score = Math.max(0, activePlayer.score - 30);
                }

                // Turn rotates to next player
                const currentIdx = lobby.players.findIndex((p) => p.id === randomPlayerId);
                let nextIdx = (currentIdx + 1) % lobby.players.length;
                // Double check to pick connected player
                let foundNext = false;
                for (let k = 0; k < lobby.players.length; k++) {
                  const checkPlayer = lobby.players[(currentIdx + 1 + k) % lobby.players.length];
                  if (checkPlayer.isConnected) {
                    nextIdx = lobby.players.indexOf(checkPlayer);
                    foundNext = true;
                    break;
                  }
                }
                const originalTurnId = lobby.activeTurnPlayerId;
                lobby.activeTurnPlayerId = lobby.players[nextIdx]?.id || originalTurnId;

                // Send mismatch event so clients can play error sound/visuals
                broadcast(code, {
                  type: 'turn_result',
                  matched: false,
                  cards: lobby.cards,
                  players: lobby.players,
                  nextTurn: lobby.activeTurnPlayerId,
                  gameWon: false,
                  winnerId: null,
                });

                // autorun flip back delay on server to maintain authoritative cards state
                setTimeout(() => {
                  const currentRoom = lobbies.get(code);
                  if (currentRoom) {
                    currentRoom.cards[firstIdx].isFlipped = false;
                    currentRoom.cards[secondIdx].isFlipped = false;
                    currentRoom.selectedCardIndices = [];
                    currentRoom.isEvaluating = false;

                    broadcast(code, {
                      type: 'cards_reset',
                      cards: currentRoom.cards,
                      activeTurnPlayerId: currentRoom.activeTurnPlayerId,
                    });
                  }
                }, 1200);
              }
            }
            break;
          }

          case 'send_message': {
            const { code, text } = payload;
            const lobby = lobbies.get(code);
            if (!lobby) return;

            const sender = lobby.players.find((p) => p.id === randomPlayerId);
            if (!sender) return;

            const message: ChatMessage = {
              id: 'msg_' + Math.random().toString(36).substr(2, 9),
              playerId: randomPlayerId,
              name: sender.name,
              text: text || '',
              timestamp: Date.now(),
            };

            lobby.messages.push(message);
            // Limit stored memory
            if (lobby.messages.length > 50) {
              lobby.messages.shift();
            }

            broadcast(code, {
              type: 'chat_message',
              message,
            });
            break;
          }

          case 'leave_lobby': {
            const { code } = payload;
            handlePlayerLeave(socket.id, code);
            break;
          }
        }
      } catch (err) {
        console.error('Error handling websocket message:', err);
      }
    });

    socket.on('disconnect', () => {
      const connInfo = socketPlayerMap.get(socket.id);
      if (connInfo && connInfo.roomCode) {
        handlePlayerLeave(socket.id, connInfo.roomCode);
      }
      socketPlayerMap.delete(socket.id);
    });
  });

  // Handle cleaner disconnection logic
  function handlePlayerLeave(socketId: string, roomCode: string) {
    const connInfo = socketPlayerMap.get(socketId);
    if (!connInfo) return;

    const lobby = lobbies.get(roomCode);
    if (!lobby) return;

    const leavingPlayerIdx = lobby.players.findIndex((p) => p.id === connInfo.playerId);
    if (leavingPlayerIdx !== -1) {
      const leavingPlayer = lobby.players[leavingPlayerIdx];
      
      if (lobby.gameStarted && !lobby.gameWon) {
        // If game is active, mark player as disconnected so they can potentially rejoin, or auto-forfeit turn
        leavingPlayer.isConnected = false;
        
        // If it was their turn, shift turn
        if (lobby.activeTurnPlayerId === leavingPlayer.id) {
          const nextIdx = lobby.players.findIndex((p) => p.id !== leavingPlayer.id && p.isConnected);
          if (nextIdx !== -1) {
            lobby.activeTurnPlayerId = lobby.players[nextIdx].id;
          }
        }
      } else {
        // Remove completely if lobby hasn't started or game is done
        lobby.players.splice(leavingPlayerIdx, 1);
      }

      // Check if any active player is left
      const activeCount = lobby.players.filter((p) => p.isConnected).length;
      if (activeCount === 0) {
        // Close room, cleanup intervals
        if (lobby.timerIntervalId) clearInterval(lobby.timerIntervalId);
        lobbies.delete(roomCode);
        return;
      }

      // If host left, assign next active player as host
      if (leavingPlayer.isHost) {
        const nextHost = lobby.players.find((p) => p.isConnected);
        if (nextHost) {
          nextHost.isHost = true;
          lobby.activeTurnPlayerId = nextHost.id;
        }
      }

      // Sync remaining lobby players
      broadcast(roomCode, {
        type: 'player_left',
        lobby: { ...lobby, messages: lobby.messages.slice(-15) },
      });
    }

    connInfo.roomCode = '';
  }

  // Vite development vs production serving logic
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer();
