import React, { useState, useEffect, useRef, useCallback, FormEvent } from 'react';
import { io, Socket } from 'socket.io-client';
import { 
  Sparkles, 
  Brain, 
  Trophy, 
  Timer, 
  RotateCcw, 
  Volume2, 
  VolumeX, 
  Info, 
  Flame, 
  Award, 
  Trash2, 
  X, 
  Play,
  Users,
  User,
  Copy,
  Plus,
  LogIn,
  Send,
  LogOut,
  Crown,
  MessageSquare,
  Check,
  Loader2,
  Lock,
  History,
  Calendar
} from 'lucide-react';

// ============================================================================
// REAL-TIME WEB AUDIO SYNTHESIZER
// ============================================================================
class SoundEffects {
  private ctx: AudioContext | null = null;
  private muted: boolean = false;

  setMuted(muted: boolean) {
    this.muted = muted;
  }

  private initCtx() {
    if (!this.ctx) {
      this.ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  playFlip() {
    if (this.muted) return;
    try {
      this.initCtx();
      if (!this.ctx) return;
      
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      
      osc.type = 'sine';
      osc.frequency.setValueAtTime(140, now);
      osc.frequency.exponentialRampToValueAtTime(70, now + 0.08);
      
      gain.gain.setValueAtTime(0.12, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);
      
      osc.start(now);
      osc.stop(now + 0.08);
    } catch (e) {
      console.warn('Audio synthesis failed', e);
    }
  }

  playMatch() {
    if (this.muted) return;
    try {
      this.initCtx();
      if (!this.ctx) return;
      
      const now = this.ctx.currentTime;
      // Cheerful E Major chord arpeggio (E4, G#4, B4, E5) with resonance
      const notes = [329.63, 415.30, 493.88, 659.25];
      
      notes.forEach((freq, idx) => {
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();
        const filter = this.ctx!.createBiquadFilter();
        
        osc.connect(filter);
        filter.connect(gain);
        gain.connect(this.ctx!.destination);
        
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, now + idx * 0.05);
        
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(1200, now);
        
        gain.gain.setValueAtTime(0, now);
        gain.gain.linearRampToValueAtTime(0.15, now + idx * 0.05 + 0.01);
        gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.05 + 0.4);
        
        osc.start(now + idx * 0.05);
        osc.stop(now + idx * 0.05 + 0.4);
      });
    } catch (e) {
      console.warn('Audio synthesis failed', e);
    }
  }

  playMismatch() {
    if (this.muted) return;
    try {
      this.initCtx();
      if (!this.ctx) return;
      
      const now = this.ctx.currentTime;
      const osc1 = this.ctx.createOscillator();
      const osc2 = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      
      osc1.connect(gain);
      osc2.connect(gain);
      gain.connect(this.ctx.destination);
      
      osc1.type = 'sawtooth';
      osc2.type = 'triangle';
      
      // Low pitched detuned buzz
      osc1.frequency.setValueAtTime(110, now);
      osc1.frequency.linearRampToValueAtTime(80, now + 0.22);
      
      osc2.frequency.setValueAtTime(108, now);
      osc2.frequency.linearRampToValueAtTime(78, now + 0.22);
      
      gain.gain.setValueAtTime(0.08, now);
      gain.gain.linearRampToValueAtTime(0.08, now + 0.05);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.22);
      
      osc1.start(now);
      osc2.start(now);
      
      osc1.stop(now + 0.22);
      osc2.stop(now + 0.22);
    } catch (e) {
      console.warn('Audio synthesis failed', e);
    }
  }

  playVictory() {
    if (this.muted) return;
    try {
      this.initCtx();
      if (!this.ctx) return;
      
      const now = this.ctx.currentTime;
      // Sparkly rising major pentatonic arpeggio (C4, D4, E4, G4, A4, C5, D5, E5, G5, C6)
      const scale = [261.63, 293.66, 329.63, 392.00, 440.00, 523.25, 587.33, 659.25, 783.99, 1046.50];
      
      scale.forEach((freq, idx) => {
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();
        const filter = this.ctx!.createBiquadFilter();
        
        osc.connect(filter);
        filter.connect(gain);
        gain.connect(this.ctx!.destination);
        
        osc.type = idx % 2 === 0 ? 'sine' : 'triangle';
        osc.frequency.setValueAtTime(freq, now + idx * 0.08);
        
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(1500, now);
        
        gain.gain.setValueAtTime(0, now);
        gain.gain.linearRampToValueAtTime(0.12, now + idx * 0.08 + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.08 + 0.5);
        
        osc.start(now + idx * 0.08);
        osc.stop(now + idx * 0.08 + 0.5);
      });
    } catch (e) {
      console.warn('Audio synthesis failed', e);
    }
  }
}

// ============================================================================
// GEOMETRIC CARD THEMES & EMOJIS
// ============================================================================
const THEMES = {
  animals: [
    { emoji: '🦊', label: 'FOX', color: 'bg-gradient-to-br from-amber-400 to-orange-500 border-amber-300 shadow-amber-200' },
    { emoji: '🦁', label: 'LION', color: 'bg-gradient-to-br from-orange-400 to-amber-500 border-orange-300 shadow-orange-200' },
    { emoji: '🐼', label: 'PANDA', color: 'bg-gradient-to-br from-slate-600 to-slate-800 border-slate-500 shadow-slate-200' },
    { emoji: '🐸', label: 'FROG', color: 'bg-gradient-to-br from-emerald-400 to-green-600 border-emerald-300 shadow-emerald-200' },
    { emoji: '🐯', label: 'TIGER', color: 'bg-gradient-to-br from-yellow-400 to-orange-500 border-yellow-300 shadow-yellow-200' },
    { emoji: '🐻', label: 'BEAR', color: 'bg-gradient-to-br from-amber-700 to-amber-900 border-amber-600 shadow-amber-300' },
    { emoji: '🐨', label: 'KOALA', color: 'bg-gradient-to-br from-zinc-400 to-zinc-600 border-zinc-300 shadow-zinc-200' },
    { emoji: '🐙', label: 'OCTOPUS', color: 'bg-gradient-to-br from-rose-400 to-pink-600 border-rose-300 shadow-rose-200' },
    { emoji: '🦄', label: 'UNICORN', color: 'bg-gradient-to-br from-fuchsia-400 to-violet-600 border-fuchsia-300 shadow-fuchsia-200' },
    { emoji: '🐝', label: 'HONEYBEE', color: 'bg-gradient-to-br from-amber-300 to-yellow-500 border-amber-200 shadow-amber-100' },
    { emoji: '🐢', label: 'TURTLE', color: 'bg-gradient-to-br from-teal-400 to-emerald-600 border-teal-300 shadow-teal-200' },
    { emoji: '🐬', label: 'DOLPHIN', color: 'bg-gradient-to-br from-cyan-400 to-blue-600 border-cyan-300 shadow-cyan-200' },
  ],
  food: [
    { emoji: '🍕', label: 'PIZZA', color: 'bg-gradient-to-br from-rose-500 to-red-600 border-red-300 shadow-red-200' },
    { emoji: '🍔', label: 'BURGER', color: 'bg-gradient-to-br from-amber-400 to-orange-500 border-amber-300 shadow-amber-200' },
    { emoji: '🍟', label: 'FRIES', color: 'bg-gradient-to-br from-yellow-300 to-amber-500 border-yellow-200 shadow-yellow-100' },
    { emoji: '🍩', label: 'DONUT', color: 'bg-gradient-to-br from-pink-400 to-fuchsia-600 border-fuchsia-300 shadow-fuchsia-200' },
    { emoji: '🍓', label: 'BERRY', color: 'bg-gradient-to-br from-rose-400 to-pink-500 border-rose-300 shadow-rose-200' },
    { emoji: '🥑', label: 'AVOCADO', color: 'bg-gradient-to-br from-emerald-400 to-green-600 border-green-300 shadow-green-200' },
    { emoji: '🍦', label: 'ICE CREAM', color: 'bg-gradient-to-br from-sky-300 to-indigo-400 border-sky-200 shadow-sky-100' },
    { emoji: '🍣', label: 'SUSHI', color: 'bg-gradient-to-br from-slate-500 to-neutral-700 border-neutral-400 shadow-neutral-200' },
    { emoji: '🌮', label: 'TACO', color: 'bg-gradient-to-br from-orange-400 to-amber-500 border-orange-300 shadow-orange-200' },
    { emoji: '🍉', label: 'MELON', color: 'bg-gradient-to-br from-rose-400 to-emerald-500 border-rose-300 shadow-rose-200' },
    { emoji: '🍪', label: 'COOKIE', color: 'bg-gradient-to-br from-amber-600 to-amber-800 border-amber-500 shadow-amber-200' },
    { emoji: '🥞', label: 'PANCAKES', color: 'bg-gradient-to-br from-yellow-400 to-amber-600 border-yellow-300 shadow-yellow-200' },
  ],
  space: [
    { emoji: '🚀', label: 'ROCKET', color: 'bg-gradient-to-br from-sky-400 to-indigo-600 border-sky-300 shadow-sky-200' },
    { emoji: '🌙', label: 'MOON', color: 'bg-gradient-to-br from-slate-300 to-slate-500 border-slate-200 shadow-slate-100' },
    { emoji: '🪐', label: 'SATURN', color: 'bg-gradient-to-br from-amber-400 to-yellow-600 border-amber-300 shadow-amber-200' },
    { emoji: '⭐', label: 'STAR', color: 'bg-gradient-to-br from-yellow-300 to-orange-400 border-yellow-200 shadow-yellow-100' },
    { emoji: '🛸', label: 'UFO', color: 'bg-gradient-to-br from-indigo-400 to-purple-600 border-indigo-300 shadow-indigo-200' },
    { emoji: '🌍', label: 'EARTH', color: 'bg-gradient-to-br from-blue-400 to-emerald-600 border-blue-300 shadow-blue-200' },
    { emoji: '☄️', label: 'COMET', color: 'bg-gradient-to-br from-slate-400 to-neutral-600 border-slate-300 shadow-slate-200' },
    { emoji: '☀️', label: 'SUN', color: 'bg-gradient-to-br from-orange-400 to-red-500 border-orange-300 shadow-orange-200' },
    { emoji: '👾', label: 'ALIEN', color: 'bg-gradient-to-br from-purple-400 to-violet-600 border-purple-300 shadow-purple-200' },
    { emoji: '🔭', label: 'TELESCOPE', color: 'bg-gradient-to-br from-zinc-500 to-slate-700 border-zinc-400 shadow-zinc-200' },
    { emoji: '🌌', label: 'GALAXY', color: 'bg-gradient-to-br from-violet-500 to-fuchsia-700 border-violet-400 shadow-violet-200' },
    { emoji: '🛰️', label: 'SATELLITE', color: 'bg-gradient-to-br from-gray-400 to-slate-600 border-gray-300 shadow-gray-200' },
  ],
  games: [
    { emoji: '⚽', label: 'SOCCER', color: 'bg-gradient-to-br from-neutral-400 to-neutral-700 border-neutral-300 shadow-neutral-200' },
    { emoji: '🏀', label: 'HOOPS', color: 'bg-gradient-to-br from-orange-400 to-red-500 border-orange-300 shadow-orange-200' },
    { emoji: '🎮', label: 'CONSOLE', color: 'bg-gradient-to-br from-indigo-400 to-indigo-600 border-indigo-300 shadow-indigo-200' },
    { emoji: '🎲', label: 'DICE', color: 'bg-gradient-to-br from-red-400 to-rose-600 border-red-300 shadow-red-200' },
    { emoji: '🎯', label: 'DART', color: 'bg-gradient-to-br from-sky-400 to-blue-600 border-sky-300 shadow-sky-200' },
    { emoji: '🏎️', label: 'RACECAR', color: 'bg-gradient-to-br from-rose-400 to-red-600 border-rose-300 shadow-rose-200' },
    { emoji: '🏆', label: 'TROPHY', color: 'bg-gradient-to-br from-yellow-300 to-amber-500 border-yellow-200 shadow-yellow-100' },
    { emoji: '🎨', label: 'PALETTE', color: 'bg-gradient-to-br from-emerald-400 to-teal-600 border-emerald-300 shadow-emerald-200' },
    { emoji: '🧩', label: 'PUZZLE', color: 'bg-gradient-to-br from-teal-400 to-cyan-600 border-teal-300 shadow-teal-200' },
    { emoji: '🎳', label: 'BOWLING', color: 'bg-gradient-to-br from-slate-400 to-slate-600 border-slate-300 shadow-slate-200' },
    { emoji: '♟️', label: 'CHESS', color: 'bg-gradient-to-br from-stone-400 to-stone-700 border-stone-400 shadow-stone-200' },
    { emoji: '🎸', label: 'GUITAR', color: 'bg-gradient-to-br from-red-400 to-rose-600 border-red-300 shadow-red-200' },
  ]
};

type ThemeName = keyof typeof THEMES;

interface GameHistoryRecord {
  id: string;
  mode: 'solo' | 'multiplayer';
  difficulty: string;
  theme: string;
  durationSeconds: number;
  completedAt: string;
  players: {
    name: string;
    score: number;
    isWinner: boolean;
    moves?: number;
  }[];
}

interface Card {
  id: string;
  value: string;
  color: string;
  label: string;
  isFlipped: boolean;
  isMatched: boolean;
}

// ============================================================================
// VICTORY CONFETTI PHYSICS CANVAS
// ============================================================================
interface ConfettiProps {
  active: boolean;
}

function VictoryConfetti({ active }: ConfettiProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    if (!active) return;
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = canvas.offsetWidth);
    let height = (canvas.height = canvas.offsetHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = canvas.offsetWidth;
      height = canvas.height = canvas.offsetHeight;
    };

    window.addEventListener('resize', handleResize);

    const colors = [
      '#FF3366', '#33CCFF', '#FFCC33', '#33FF99', 
      '#9933FF', '#FF5733', '#8CFF33', '#33FFDF'
    ];

    interface Particle {
      x: number;
      y: number;
      size: number;
      color: string;
      speedX: number;
      speedY: number;
      rotation: number;
      rotationSpeed: number;
      shape: 'circle' | 'square' | 'triangle';
    }

    const particles: Particle[] = [];
    const maxParticles = 120;

    // Create particles with randomized vectors and gravity parameters
    for (let i = 0; i < maxParticles; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * -height - 20, 
        size: Math.random() * 8 + 6,
        color: colors[Math.floor(Math.random() * colors.length)],
        speedX: Math.random() * 6 - 3,
        speedY: Math.random() * 5 + 3,
        rotation: Math.random() * 360,
        rotationSpeed: Math.random() * 4 - 2,
        shape: ['circle', 'square', 'triangle'][Math.floor(Math.random() * 3)] as any,
      });
    }

    const draw = () => {
      ctx.clearRect(0, 0, width, height);

      particles.forEach((p) => {
        p.y += p.speedY;
        p.x += p.speedX;
        p.rotation += p.rotationSpeed;

        // Gravity physics & atmospheric resistance
        p.speedY += 0.05; 
        p.speedX *= 0.98; 

        // Reset particle when it drops off bottom
        if (p.y > height) {
          p.y = -20;
          p.x = Math.random() * width;
          p.speedY = Math.random() * 4 + 3;
          p.speedX = Math.random() * 6 - 3;
        }

        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate((p.rotation * Math.PI) / 180);
        ctx.fillStyle = p.color;

        ctx.beginPath();
        if (p.shape === 'circle') {
          ctx.arc(0, 0, p.size / 2, 0, Math.PI * 2);
          ctx.fill();
        } else if (p.shape === 'square') {
          ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size);
        } else if (p.shape === 'triangle') {
          ctx.moveTo(0, -p.size / 2);
          ctx.lineTo(p.size / 2, p.size / 2);
          ctx.lineTo(-p.size / 2, p.size / 2);
          ctx.closePath();
          ctx.fill();
        }
        ctx.restore();
      });

      animationFrameId = requestAnimationFrame(draw);
    };

    draw();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
    };
  }, [active]);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 w-full h-full pointer-events-none z-50 rounded-[40px]"
    />
  );
}

// ============================================================================
// MAIN REUSABLE MEMORY MATCH APP
// ============================================================================
export default function App() {
  // Game parameters
  const [theme, setTheme] = useState<ThemeName>(() => {
    return (localStorage.getItem('memoryMatch_theme') as ThemeName) || 'animals';
  });
  const [difficulty, setDifficulty] = useState<string>(() => {
    return localStorage.getItem('memoryMatch_difficulty') || 'medium'; // easy (12), medium (16), hard (20)
  });

  // Core game states
  const [cards, setCards] = useState<Card[]>([]);
  const [flippedIndices, setFlippedIndices] = useState<number[]>([]);
  const [isEvaluating, setIsEvaluating] = useState<boolean>(false);
  const [moves, setMoves] = useState<number>(0);
  const [score, setScore] = useState<number>(1000);
  const [streak, setStreak] = useState<number>(0);
  
  // Timing states
  const [seconds, setSeconds] = useState<number>(0);
  const [gameStarted, setGameStarted] = useState<boolean>(false);
  const [gameWon, setGameWon] = useState<boolean>(false);

  // Preference and utility states
  const [activeTab, setActiveTab] = useState<'solo' | 'multiplayer' | 'history'>('solo');
  const [gameHistory, setGameHistory] = useState<GameHistoryRecord[]>(() => {
    try {
      const saved = localStorage.getItem('memoryMatch_gameHistory');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const saveGameRecord = useCallback((
    mode: 'solo' | 'multiplayer',
    playersList: { name: string; score: number; isWinner: boolean; moves?: number }[],
    durationSec: number,
    gameDifficulty: string,
    gameTheme: string
  ) => {
    const newRecord: GameHistoryRecord = {
      id: `game_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
      mode,
      difficulty: gameDifficulty,
      theme: gameTheme,
      durationSeconds: durationSec,
      completedAt: new Date().toISOString(),
      players: playersList
    };

    setGameHistory(prev => {
      const updated = [newRecord, ...prev].slice(0, 50);
      localStorage.setItem('memoryMatch_gameHistory', JSON.stringify(updated));
      return updated;
    });

    // POST to backend SQLite database
    fetch('/api/history', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(newRecord),
    }).catch(err => console.error('Failed to save record to SQLite DB:', err));
  }, []);

  // Fetch unified history from SQLite database
  const fetchHistoryFromDb = useCallback(async () => {
    try {
      const res = await fetch('/api/history');
      if (res.ok) {
        const dbHistory = await res.json();
        if (dbHistory && dbHistory.length > 0) {
          setGameHistory(dbHistory);
          localStorage.setItem('memoryMatch_gameHistory', JSON.stringify(dbHistory));
        }
      }
    } catch (err) {
      console.error('Failed to fetch game history from SQLite DB:', err);
    }
  }, []);

  useEffect(() => {
    fetchHistoryFromDb();
  }, [fetchHistoryFromDb, activeTab]);

  const [soundMuted, setSoundMuted] = useState<boolean>(() => {
    return localStorage.getItem('memoryMatch_soundMuted') === 'true';
  });
  const [showRules, setShowRules] = useState<boolean>(false);
  const [showConfirmReset, setShowConfirmReset] = useState<boolean>(false);

  // ============================================================================
  // MULTIPLAYER REAL-TIME STATE & SOCKET HANDLERS
  // ============================================================================
  const [isMultiplayer, setIsMultiplayer] = useState<boolean>(false);

  useEffect(() => {
    setIsMultiplayer(activeTab === 'multiplayer');
  }, [activeTab]);
  const [playerId, setPlayerId] = useState<string | null>(null);
  const [roomCode, setRoomCode] = useState<string>('');
  const [lobby, setLobby] = useState<any>(null);
  const [isConnecting, setIsConnecting] = useState<boolean>(false);
  const [wsError, setWsError] = useState<string | null>(null);
  const [nickname, setNickname] = useState<string>(() => {
    return localStorage.getItem('memoMatch_nickname') || 'Player_' + Math.floor(Math.random() * 900 + 100);
  });
  const [joinCodeInput, setJoinCodeInput] = useState<string>('');
  const wsRef = useRef<Socket | null>(null);
  const [copiedCode, setCopiedCode] = useState<boolean>(false);
  const [chatInput, setChatInput] = useState<string>('');
  const chatEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    localStorage.setItem('memoMatch_nickname', nickname);
  }, [nickname]);

  const handleServerPayload = useCallback((payload: any) => {
    switch (payload.type) {
      case 'lobby_created': {
        setPlayerId(payload.playerId);
        setRoomCode(payload.code);
        setLobby(payload.lobby);
        setWsError(null);
        break;
      }
      case 'lobby_joined': {
        setPlayerId(payload.playerId);
        setRoomCode(payload.code);
        setLobby(payload.lobby);
        setWsError(null);
        break;
      }
      case 'player_joined':
      case 'player_left': {
        setLobby(payload.lobby);
        break;
      }
      case 'game_started': {
        setLobby(payload.lobby);
        break;
      }
      case 'card_flipped_update': {
        setLobby((prev: any) => {
          if (!prev) return prev;
          return {
            ...prev,
            cards: payload.cards,
            selectedCardIndices: payload.selectedIndices,
          };
        });
        soundEffects.current.playFlip();
        break;
      }
      case 'turn_result': {
        setLobby((prev: any) => {
          if (!prev) return prev;
          return {
            ...prev,
            cards: payload.cards,
            players: payload.players,
            activeTurnPlayerId: payload.nextTurn,
            gameWon: payload.gameWon,
            winnerId: payload.winnerId,
          };
        });

        if (payload.matched) {
          soundEffects.current.playMatch();
          if (payload.gameWon) {
            soundEffects.current.playVictory();
            
            // Save multiplayer game history record once on transition
            if (!lobby?.gameWon) {
              const playersList = (payload.players || []).map((p: any) => ({
                name: p.name,
                score: p.score,
                isWinner: p.id === payload.winnerId
              }));
              const gameTheme = lobby?.theme || 'animals';
              const gameDiff = lobby?.difficulty || 'medium';
              const gameTime = lobby?.secondsElapsed || 0;
              saveGameRecord('multiplayer', playersList, gameTime, gameDiff, gameTheme);
            }
          }
        } else {
          soundEffects.current.playMismatch();
        }
        break;
      }
      case 'cards_reset': {
        setLobby((prev: any) => {
          if (!prev) return prev;
          return {
            ...prev,
            cards: payload.cards,
            activeTurnPlayerId: payload.activeTurnPlayerId,
            selectedCardIndices: [],
          };
        });
        break;
      }
      case 'time_tick': {
        setLobby((prev: any) => {
          if (!prev) return prev;
          return {
            ...prev,
            secondsElapsed: payload.secondsElapsed,
            players: payload.players,
          };
        });
        break;
      }
      case 'chat_message': {
        setLobby((prev: any) => {
          if (!prev) return prev;
          return {
            ...prev,
            messages: [...(prev.messages || []), payload.message].slice(-50),
          };
        });
        break;
      }
      case 'error': {
        setWsError(payload.message);
        break;
      }
    }
  }, []);

  const connectWebSocket = useCallback((): Promise<Socket> => {
    if (wsRef.current && wsRef.current.connected) {
      return Promise.resolve(wsRef.current);
    }

    setIsConnecting(true);
    setWsError(null);

    return new Promise<Socket>((resolve, reject) => {
      try {
        const socketUrl = `${window.location.protocol}//${window.location.host}`;
        const socket = io(socketUrl, {
          transports: ['websocket'],
          autoConnect: true,
        });

        socket.on('connect', () => {
          setIsConnecting(false);
          wsRef.current = socket;
          resolve(socket);
        });

        socket.on('message', (payload: any) => {
          handleServerPayload(payload);
        });

        socket.on('connect_error', (err) => {
          console.error('Socket.io Connection error:', err);
          setIsConnecting(false);
          setWsError('Failed to connect to the game server.');
          reject(err);
        });

        socket.on('disconnect', () => {
          console.log('Socket.io connection disconnected');
          wsRef.current = null;
          setPlayerId(null);
          setLobby(null);
        });
      } catch (e) {
        console.error(e);
        setIsConnecting(false);
        setWsError('Socket.io is not supported in this environment.');
        reject(e);
      }
    });
  }, [handleServerPayload]);

  const handleCreateLobby = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!nickname.trim()) {
      setWsError('Please enter a nickname first.');
      return;
    }
    try {
      const socket = await connectWebSocket();
      socket.emit('message', {
        type: 'create_lobby',
        name: nickname,
        difficulty,
        theme,
      });
    } catch (err) {
      console.error(err);
    }
  };

  const handleJoinLobby = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!nickname.trim()) {
      setWsError('Please enter a nickname first.');
      return;
    }
    if (!joinCodeInput.trim() || joinCodeInput.trim().length !== 4) {
      setWsError('Lobby Code must be exactly 4 characters.');
      return;
    }
    try {
      const socket = await connectWebSocket();
      socket.emit('message', {
        type: 'join_lobby',
        code: joinCodeInput.toUpperCase().trim(),
        name: nickname,
      });
    } catch (err) {
      console.error(err);
    }
  };

  const handleStartGameMultiplayer = () => {
    if (wsRef.current && wsRef.current.connected && roomCode) {
      wsRef.current.emit('message', {
        type: 'start_game',
        code: roomCode,
      });
    }
  };

  const handleCardClickMultiplayer = (index: number) => {
    if (!lobby || !lobby.gameStarted || lobby.gameWon || lobby.isEvaluating) return;
    
    if (lobby.activeTurnPlayerId !== playerId) {
      return;
    }

    const card = lobby.cards[index];
    if (!card || card.isFlipped || card.isMatched) return;

    if (wsRef.current && wsRef.current.connected && roomCode) {
      wsRef.current.emit('message', {
        type: 'flip_card',
        code: roomCode,
        index,
      });
    }
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || !lobby || !roomCode) return;

    if (wsRef.current && wsRef.current.connected) {
      wsRef.current.emit('message', {
        type: 'send_message',
        code: roomCode,
        text: chatInput,
      });
      setChatInput('');
    }
  };

  const handleLeaveLobby = () => {
    if (wsRef.current && wsRef.current.connected && roomCode) {
      wsRef.current.emit('message', {
        type: 'leave_lobby',
        code: roomCode,
      });
    }
    setLobby(null);
    setRoomCode('');
    setPlayerId(null);
    if (wsRef.current) {
      wsRef.current.disconnect();
    }
  };

  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [lobby?.messages]);

  useEffect(() => {
    return () => {
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, []);

  // High scores tracking
  const [bestMoves, setBestMoves] = useState<string>('--');
  const [bestTime, setBestTime] = useState<string>('--');
  const [bestScore, setBestScore] = useState<string>('--');

  // Synthesizer ref
  const soundEffects = useRef(new SoundEffects());

  // Format MM:SS
  const formatTime = (totalSeconds: number) => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Sync preferences
  useEffect(() => {
    localStorage.setItem('memoryMatch_theme', theme);
  }, [theme]);

  useEffect(() => {
    localStorage.setItem('memoryMatch_difficulty', difficulty);
  }, [difficulty]);

  useEffect(() => {
    localStorage.setItem('memoryMatch_soundMuted', soundMuted.toString());
    soundEffects.current.setMuted(soundMuted);
  }, [soundMuted]);

  // Load high scores
  const loadHighScores = useCallback(() => {
    const bScore = localStorage.getItem(`memoryMatch_bestScore_${difficulty}`) || '--';
    const bMoves = localStorage.getItem(`memoryMatch_bestMoves_${difficulty}`) || '--';
    const bTime = localStorage.getItem(`memoryMatch_bestTime_${difficulty}`);
    
    setBestScore(bScore);
    setBestMoves(bMoves);
    setBestTime(bTime ? formatTime(parseInt(bTime)) : '--');
  }, [difficulty]);

  useEffect(() => {
    loadHighScores();
  }, [difficulty, loadHighScores]);

  // Restart / Initializer
  const handleRestart = useCallback(() => {
    let numPairs = 8; // default medium (16 cards)
    if (difficulty === 'easy') numPairs = 6; // easy (12 cards)
    else if (difficulty === 'hard') numPairs = 10; // hard (20 cards)

    const selectedThemeList = THEMES[theme].slice(0, numPairs);
    // Paired list
    const paired = [...selectedThemeList, ...selectedThemeList];

    // Card objects
    const cardObjects: Card[] = paired.map((item, index) => ({
      id: `${item.label}-${index}`,
      value: item.emoji,
      color: item.color,
      label: item.label,
      isFlipped: false,
      isMatched: false,
    }));

    // Fisher-Yates Shuffling algorithm
    for (let i = cardObjects.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      const temp = cardObjects[i];
      cardObjects[i] = cardObjects[j];
      cardObjects[j] = temp;
    }

    setCards(cardObjects);
    setFlippedIndices([]);
    setIsEvaluating(false);
    setMoves(0);
    setScore(1000);
    setStreak(0);
    setSeconds(0);
    setGameStarted(false);
    setGameWon(false);
  }, [theme, difficulty]);

  // Trigger initial shuffle and restart on settings change
  useEffect(() => {
    handleRestart();
  }, [theme, difficulty, handleRestart]);

  // Real-time ticking scoring and time penalty
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (gameStarted && !gameWon) {
      interval = setInterval(() => {
        setSeconds(prev => prev + 1);
        setScore(prev => Math.max(0, prev - 1)); // -1 point decay per second elapsed
      }, 1000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [gameStarted, gameWon]);

  // Card click callback with matching evaluation algorithm
  const handleCardClick = (index: number) => {
    // Escape guards
    if (
      isEvaluating || 
      cards[index].isFlipped || 
      cards[index].isMatched || 
      gameWon
    ) {
      return;
    }

    // Play tactile synthesized pop tone
    soundEffects.current.playFlip();

    // Lazy start timer
    if (!gameStarted) {
      setGameStarted(true);
    }

    // Flip card visual action
    const nextCards = cards.map((c, idx) => idx === index ? { ...c, isFlipped: true } : c);
    setCards(nextCards);

    const nextFlipped = [...flippedIndices, index];
    setFlippedIndices(nextFlipped);

    // Evaluate pair matching when 2 cards are turned
    if (nextFlipped.length === 2) {
      const [firstIdx, secondIdx] = nextFlipped;
      setMoves(prev => prev + 1);

      if (nextCards[firstIdx].value === nextCards[secondIdx].value) {
        // MATCH SCENARIO
        const matchedCards = nextCards.map((c, idx) => 
          idx === firstIdx || idx === secondIdx ? { ...c, isMatched: true, isFlipped: false } : c
        );

        soundEffects.current.playMatch();
        
        // Dynamic streak rewards
        const currentStreak = streak + 1;
        setStreak(currentStreak);
        
        const streakMultiplierBonus = (currentStreak - 1) * 50;
        const reward = 200 + streakMultiplierBonus;
        const nextScore = score + reward;
        setScore(nextScore);

        setCards(matchedCards);
        setFlippedIndices([]);

        // Determine clear win state
        const allMatched = matchedCards.every(c => c.isMatched);
        if (allMatched) {
          setGameWon(true);
          setGameStarted(false);
          soundEffects.current.playVictory();

          // Sync personal high scores
          const finalMovesCount = moves + 1;
          const currentBestScore = localStorage.getItem(`memoryMatch_bestScore_${difficulty}`) || '0';
          const currentBestMoves = localStorage.getItem(`memoryMatch_bestMoves_${difficulty}`) || '9999';
          const currentBestTime = localStorage.getItem(`memoryMatch_bestTime_${difficulty}`) || '999999';

          if (nextScore > parseInt(currentBestScore)) {
            localStorage.setItem(`memoryMatch_bestScore_${difficulty}`, nextScore.toString());
          }
          if (finalMovesCount < parseInt(currentBestMoves)) {
            localStorage.setItem(`memoryMatch_bestMoves_${difficulty}`, finalMovesCount.toString());
          }
          if (seconds < parseInt(currentBestTime)) {
            localStorage.setItem(`memoryMatch_bestTime_${difficulty}`, seconds.toString());
          }

          // Save game history record
          saveGameRecord(
            'solo',
            [
              {
                name: nickname || 'Solo Player',
                score: nextScore,
                isWinner: true,
                moves: finalMovesCount
              }
            ],
            seconds,
            difficulty,
            theme
          );

          loadHighScores();
        }
      } else {
        // MISMATCH SCENARIO
        setIsEvaluating(true);
        soundEffects.current.playMismatch();
        setStreak(0);
        setScore(prev => Math.max(0, prev - 30)); // -30 points mismatch penalty

        // Keep face up temporarily before automated flip-back (1s delay)
        setTimeout(() => {
          setCards(prevCards => prevCards.map((c, idx) => 
            idx === firstIdx || idx === secondIdx ? { ...c, isFlipped: false } : c
          ));
          setFlippedIndices([]);
          setIsEvaluating(false);
        }, 1000);
      }
    }
  };

  // Reset High scores in LocalStorage with inline state reset
  const handleResetHighScores = () => {
    localStorage.removeItem(`memoryMatch_bestScore_${difficulty}`);
    localStorage.removeItem(`memoryMatch_bestMoves_${difficulty}`);
    localStorage.removeItem(`memoryMatch_bestTime_${difficulty}`);
    loadHighScores();
    setShowConfirmReset(false);
  };

  // Game details computed for stats
  const totalPairs = difficulty === 'easy' ? 6 : difficulty === 'hard' ? 10 : 8;
  const matchedPairsCount = cards.filter(c => c.isMatched).length / 2;

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-800 flex flex-col font-sans relative overflow-x-hidden" id="app_root">
      
      {/* Sleek Theme Header Navigation */}
      <header className="w-full max-w-6xl mx-auto px-6 md:px-12 py-8 flex flex-col sm:flex-row justify-between items-center gap-6" id="app_header">
        <div className="flex items-center gap-3.5">
          <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white font-bold text-xl shadow-lg shadow-indigo-200 transform -rotate-12 hover:rotate-12 transition-transform duration-300">
            M
          </div>
          <div>
            <h1 className="text-2xl font-extrabold tracking-tight text-indigo-950 uppercase italic">MEMOMATCH</h1>
            <p className="text-[10px] text-indigo-500 font-bold uppercase tracking-widest block leading-none mt-0.5">Memory Match Edition</p>
          </div>
        </div>
        
        <div className="flex items-center gap-4 sm:gap-8 flex-wrap justify-center">
          {/* Real-time Dynamic Best Record from Theme */}
          <div className="flex flex-col items-center sm:items-end">
            <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Best Record</span>
            <span className="text-xl font-mono font-bold text-indigo-600">
              {bestTime !== '--' ? bestTime : '00:00'}{' '}
              <span className="text-sm text-slate-400 font-sans">/ {bestMoves !== '--' ? `${bestMoves} Moves` : '--'}</span>
            </span>
          </div>

          <div className="flex items-center gap-2">
            {/* Rules trigger button - Sleek Rounded Pill */}
            <button
              onClick={() => setShowRules(true)}
              className="px-6 py-2.5 bg-white border border-slate-200 rounded-full text-sm font-bold text-slate-700 shadow-sm hover:bg-slate-50 transition-colors cursor-pointer flex items-center gap-1.5"
              id="rules_button"
            >
              <Info size={15} className="text-slate-500" />
              <span>Rules</span>
            </button>

            {/* Mute button - Sleek Rounded Icon Button */}
            <button
              onClick={() => setSoundMuted(!soundMuted)}
              className={`p-2.5 rounded-full transition-colors cursor-pointer flex items-center justify-center ${
                soundMuted 
                  ? 'bg-rose-50 text-rose-600 border border-rose-100' 
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
              title={soundMuted ? "Unmute sounds" : "Mute sounds"}
              id="mute_button"
            >
              {soundMuted ? <VolumeX size={18} /> : <Volume2 size={18} />}
            </button>
          </div>
        </div>
      </header>

      {/* Dynamic Mode Switcher Tab Bar */}
      <div className="w-full max-w-6xl mx-auto px-6 md:px-12 mb-6" id="mode_switcher_container">
        <div className="flex bg-slate-100 p-1.5 rounded-2xl max-w-md mx-auto sm:mx-0 border border-slate-200 shadow-xs">
          <button 
            onClick={() => {
              setActiveTab('solo');
              setWsError(null);
            }}
            className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-2 ${activeTab === 'solo' ? 'bg-white text-indigo-950 shadow-sm border border-slate-200/50' : 'text-slate-500 hover:text-slate-900'}`}
          >
            <Brain size={14} />
            <span>Solo Play</span>
          </button>
          <button 
            onClick={() => {
              setActiveTab('multiplayer');
              setWsError(null);
            }}
            className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-2 ${activeTab === 'multiplayer' ? 'bg-white text-indigo-950 shadow-sm border border-slate-200/50' : 'text-slate-500 hover:text-slate-900'}`}
          >
            <Users size={14} />
            <span>Multiplayer</span>
          </button>
          <button 
            onClick={() => {
              setActiveTab('history');
              setWsError(null);
            }}
            className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-2 ${activeTab === 'history' ? 'bg-white text-indigo-950 shadow-sm border border-slate-200/50' : 'text-slate-500 hover:text-slate-900'}`}
          >
            <History size={14} />
            <span>Game History</span>
          </button>
        </div>
      </div>

      {activeTab === 'solo' && (
        /* Main Responsive Layout Grid (Solo Mode) */
        <main className="flex-1 w-full max-w-6xl mx-auto px-6 md:px-12 pb-12 flex flex-col lg:flex-row gap-8 lg:gap-12" id="app_main">
          
          {/* Left Column: Stats & Controls */}
          <div className="w-full lg:w-64 flex flex-col gap-6 shrink-0" id="left_sidebar">
            
            {/* Dynamic Stats Panel Card from Theme */}
            <div className="p-6 bg-white rounded-3xl shadow-sm border border-slate-100 flex flex-col gap-5" id="stats_panel">
              <div>
                <label className="text-[11px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Timer</label>
                <div className="text-4xl font-mono font-bold text-slate-900 flex items-center gap-1.5">
                  {formatTime(seconds)}
                  {gameStarted && (
                    <span className="flex h-2.5 w-2.5 relative">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
                    </span>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 pt-1 border-t border-slate-100">
                <div>
                  <label className="text-[11px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Moves</label>
                  <div className="text-2xl font-mono font-bold text-slate-900">{moves}</div>
                </div>
                <div>
                  <label className="text-[11px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Pairs</label>
                  <div className="text-2xl font-mono font-bold text-slate-900">
                    {matchedPairsCount}<span className="text-slate-300 text-lg">/{totalPairs}</span>
                  </div>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-between items-center">
                <div>
                  <label className="text-[11px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Active Score</label>
                  <div className="text-xl font-mono font-bold text-indigo-600">{score} <span className="text-xs font-sans text-slate-400">pts</span></div>
                </div>
                {streak > 0 && (
                  <div className="flex items-center gap-1 bg-amber-50 px-2 py-1 rounded-lg border border-amber-100 text-amber-700 animate-pulse" title={`Streak Bonus: x${streak}`}>
                    <Flame size={12} className="fill-amber-500 text-amber-500" />
                    <span className="font-mono text-xs font-bold">x{streak}</span>
                  </div>
                )}
              </div>
            </div>

            {/* New Game Button - Primary Action Card */}
            <button
              onClick={handleRestart}
              className="w-full py-5 bg-indigo-600 text-white rounded-3xl font-bold text-lg shadow-xl shadow-indigo-100 hover:bg-indigo-700 transition-all flex items-center justify-center gap-3 cursor-pointer group hover:scale-[1.02] active:scale-[0.98]"
              id="new_game_button"
            >
              <RotateCcw size={20} className="group-hover:rotate-45 transition-transform duration-300" />
              <span>New Game</span>
            </button>

            {/* Customization Panel (Grid size & Theme) */}
            <div className="p-5 bg-white rounded-3xl shadow-sm border border-slate-100 flex flex-col gap-4" id="customization_panel">
              <div>
                <label className="text-[11px] font-bold text-slate-400 uppercase tracking-widest block mb-2">Grid Size</label>
                <div className="grid grid-cols-3 gap-1 bg-slate-50 border border-slate-100 p-1 rounded-xl">
                  <button
                    onClick={() => setDifficulty('easy')}
                    className={`py-2 text-[11px] font-bold rounded-lg transition-all cursor-pointer ${
                      difficulty === 'easy' 
                        ? 'bg-white text-slate-900 shadow-xs border border-slate-200/50' 
                        : 'text-slate-500 hover:text-slate-900'
                    }`}
                    id="difficulty_easy"
                  >
                    3x4
                  </button>
                  <button
                    onClick={() => setDifficulty('medium')}
                    className={`py-2 text-[11px] font-bold rounded-lg transition-all cursor-pointer ${
                      difficulty === 'medium' 
                        ? 'bg-white text-slate-900 shadow-xs border border-slate-200/50' 
                        : 'text-slate-500 hover:text-slate-900'
                    }`}
                    id="difficulty_medium"
                  >
                    4x4
                  </button>
                  <button
                    onClick={() => setDifficulty('hard')}
                    className={`py-2 text-[11px] font-bold rounded-lg transition-all cursor-pointer ${
                      difficulty === 'hard' 
                        ? 'bg-white text-slate-900 shadow-xs border border-slate-200/50' 
                        : 'text-slate-500 hover:text-slate-900'
                    }`}
                    id="difficulty_hard"
                  >
                    4x5
                  </button>
                </div>
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-400 uppercase tracking-widest block mb-2">Card Theme</label>
                <div className="grid grid-cols-2 gap-1.5">
                  {(Object.keys(THEMES) as ThemeName[]).map((themeKey) => {
                    const isActive = theme === themeKey;
                    const sampleEmoji = THEMES[themeKey][0].emoji;
                    return (
                      <button
                        key={themeKey}
                        onClick={() => setTheme(themeKey)}
                        className={`px-3 py-2 rounded-xl border text-left transition-all cursor-pointer flex items-center justify-between ${
                          isActive 
                            ? 'bg-indigo-50/50 border-indigo-200 text-indigo-900 font-bold shadow-xs' 
                            : 'bg-white border-slate-100 text-slate-600 hover:bg-slate-50'
                        }`}
                        id={`theme_button_${themeKey}`}
                      >
                        <span className="text-[11px] capitalize">{themeKey}</span>
                        <span className="text-sm">{sampleEmoji}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Personal Record Reset Trigger */}
            <div className="px-1 flex justify-between items-center" id="score_management_container">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-widest">Saved Records</span>
              {(bestScore !== '--' || bestMoves !== '--') && (
                <button
                  onClick={() => setShowConfirmReset(true)}
                  className="text-[10px] text-slate-400 hover:text-rose-500 font-bold transition-all flex items-center gap-1 cursor-pointer"
                  title="Clear personal records"
                  id="reset_highscores_trigger"
                >
                  <Trash2 size={11} /> Clear Bests
                </button>
              )}
            </div>

            {/* Multiplayer Status Indicator Box from Theme */}
            <div className="p-4 bg-slate-50/50 border border-slate-100 rounded-3xl flex gap-3" id="multiplayer_off_row">
              <div className="flex -space-x-2 overflow-hidden shrink-0">
                <img className="inline-block h-8 w-8 rounded-full ring-2 ring-white bg-indigo-100" src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%236366f1'%3E%3Cpath d='M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z'/%3E%3C/svg%3E" alt="User" />
                <img className="inline-block h-8 w-8 rounded-full ring-2 ring-white bg-emerald-100" src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%2310b981'%3E%3Cpath d='M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z'/%3E%3C/svg%3E" alt="User" />
              </div>
              <span className="text-[11px] text-slate-500 font-bold uppercase tracking-wider self-center">Multiplayer: Off</span>
            </div>

          </div>

          {/* Right Column: Game Grid Container */}
          <div className="flex-1 flex items-center justify-center bg-white rounded-[40px] border border-slate-100 shadow-xl relative min-h-[460px]" id="game_stage_container">
            
            {/* Background Confetti on Win State */}
            <VictoryConfetti active={gameWon} />

            {/* Victory Overlay Card */}
            {gameWon && (
              <div className="absolute inset-0 bg-white/95 backdrop-blur-xs rounded-[40px] z-40 flex flex-col items-center justify-center p-6 text-center animate-fade-in" id="victory_card">
                <div className="w-16 h-16 rounded-full bg-emerald-50 border-2 border-emerald-100 flex items-center justify-center text-emerald-500 shadow-sm mb-4 animate-bounce">
                  <Award size={36} className="stroke-[2.5]" />
                </div>
                
                <h2 className="text-3xl font-extrabold tracking-tight text-slate-900 uppercase font-sans italic">
                  Victory!
                </h2>
                <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mt-1">
                  You solved the board
                </p>

                {/* Final Stats Board */}
                <div className="grid grid-cols-2 gap-3 max-w-sm w-full my-6 bg-[#F8FAFC] border border-slate-100 p-4 rounded-2xl text-slate-700">
                  <div className="flex flex-col items-center p-2.5 bg-white border border-slate-100 rounded-xl shadow-xs">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Final Score</span>
                    <span className="text-xl font-bold font-mono text-indigo-600 mt-1">{score}</span>
                  </div>
                  <div className="flex flex-col items-center p-2.5 bg-white border border-slate-100 rounded-xl shadow-xs">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Time Taken</span>
                    <span className="text-xl font-bold font-mono text-slate-800 mt-1">{formatTime(seconds)}</span>
                  </div>
                  <div className="flex flex-col items-center p-2.5 bg-white border border-slate-100 rounded-xl shadow-xs col-span-2">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Total Moves</span>
                    <span className="text-xl font-bold font-mono text-slate-800 mt-1">{moves} Moves</span>
                  </div>
                </div>

                {/* Restart Controls inside win panel */}
                <button
                  onClick={handleRestart}
                  className="px-6 py-3.5 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold transition-all shadow-md hover:shadow-lg cursor-pointer flex items-center gap-2 transform active:scale-95"
                  id="victory_play_again_button"
                >
                  <RotateCcw size={16} />
                  <span>Play Again</span>
                </button>
              </div>
            )}

            {/* Inactive State Call-to-Action Start Button Overlay */}
            {!gameStarted && !gameWon && moves === 0 && (
              <div className="absolute inset-0 bg-[#F8FAFC]/60 backdrop-blur-xs rounded-[40px] z-10 flex flex-col items-center justify-center p-6 text-center" id="play_start_overlay">
                <button
                  onClick={() => {
                    setGameStarted(true);
                    soundEffects.current.playFlip();
                  }}
                  className="px-6 py-4 rounded-2xl bg-white border border-slate-100 shadow-md hover:shadow-xl hover:scale-105 active:scale-95 text-slate-800 font-bold tracking-tight text-sm transition-all flex items-center gap-3 cursor-pointer group"
                  id="primary_start_game_button"
                >
                  <div className="w-8 h-8 rounded-lg bg-indigo-50 flex items-center justify-center text-indigo-600 group-hover:bg-indigo-100 transition-colors">
                    <Play size={16} className="fill-indigo-600 ml-0.5" />
                  </div>
                  <div className="text-left">
                    <span className="block font-extrabold uppercase leading-none text-slate-900">Start Game</span>
                    <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mt-0.5">Activate Timer</span>
                  </div>
                </button>
              </div>
            )}

            {/* Dynamic Card Grid matching chosen layout */}
            <div className="p-8 w-full h-full flex items-center justify-center">
              <div 
                className={`grid gap-4 w-full select-none justify-center ${
                  difficulty === 'easy' 
                    ? 'grid-cols-3 max-w-md' 
                    : difficulty === 'hard' 
                      ? 'grid-cols-4 sm:grid-cols-5 max-w-2xl' 
                      : 'grid-cols-4 max-w-xl'
                }`}
                id="memory_cards_grid"
              >
                {cards.map((card, idx) => {
                  return (
                    <div 
                      key={card.id}
                      onClick={() => handleCardClick(idx)}
                      className="aspect-square perspective-1000 cursor-pointer group relative w-full"
                      style={{ minHeight: '80px', minWidth: '80px' }}
                      id={`card_container_${idx}`}
                    >
                      <div className={`relative w-full h-full transition-transform duration-500 preserve-3d ${
                        card.isFlipped || card.isMatched ? 'rotate-y-180' : ''
                      }`}>
                        
                        {/* CARD FRONT: Facedown/Hidden state - Sleek Style with circle */}
                        <div className="absolute inset-0 w-full h-full bg-slate-50 border-2 border-slate-100 rounded-3xl flex items-center justify-center shadow-xs group-hover:border-indigo-200 group-hover:shadow-md transition-all backface-hidden">
                          <div className="w-12 h-12 rounded-full bg-slate-200/50 opacity-25 group-hover:scale-110 transition-transform duration-300" />
                        </div>

                        {/* CARD BACK: Revealed/Flipped/Matched state */}
                        <div className={`absolute inset-0 w-full h-full rounded-3xl border-2 flex flex-col items-center justify-center backface-hidden rotate-y-180 transition-all ${
                          card.isMatched 
                            ? 'bg-emerald-50 border-emerald-500 text-emerald-800 shadow-md relative overflow-hidden' 
                            : `${card.color} text-white shadow-lg`
                        }`}>
                          <span className="text-3xl md:text-4xl filter drop-shadow-xs mb-1 select-none">
                            {card.value}
                          </span>
                          <span className="text-[9px] font-extrabold font-mono uppercase tracking-widest opacity-75 leading-none select-none">
                            {card.label}
                          </span>

                          {card.isMatched && (
                            <div className="absolute top-2 right-2 bg-emerald-500 rounded-full p-0.5">
                              <svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 20 20">
                                <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd"/>
                              </svg>
                            </div>
                          )}
                        </div>

                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

          </div>

        </main>
      )}

      {activeTab === 'multiplayer' && (
        /* MULTIPLAYER LOBBY SYSTEM (Online Mode) */
        <main className="flex-1 w-full max-w-6xl mx-auto px-6 md:px-12 pb-12 flex flex-col gap-8" id="multiplayer_main">
          {wsError && (
            <div className="p-4 bg-rose-50 border border-rose-100 text-rose-700 rounded-2xl font-bold text-xs flex items-center gap-2 max-w-3xl mx-auto w-full animate-pulse">
              <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping"></span>
              <span>Error: {wsError}</span>
            </div>
          )}

          {lobby === null ? (
            /* LOBBY ENTRY FORMS (MAKE / JOIN) */
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto w-full">
              
              {/* Common Nickname Block on top of columns */}
              <div className="md:col-span-2 p-6 bg-white rounded-3xl border border-slate-100 shadow-sm flex flex-col gap-4">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-indigo-50 flex items-center justify-center text-indigo-600 font-bold text-sm">
                    1
                  </div>
                  <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider">Set Your Nickname</h3>
                </div>
                <div>
                  <div className="relative max-w-md">
                    <User size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input 
                      type="text" 
                      value={nickname} 
                      onChange={(e) => setNickname(e.target.value)}
                      placeholder="Enter multiplayer alias..."
                      className="w-full pl-11 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-slate-800 font-extrabold text-sm focus:outline-hidden focus:border-indigo-400 focus:bg-white transition-all"
                      maxLength={15}
                    />
                  </div>
                  <p className="text-[10px] text-slate-400 font-medium mt-1">This identifier is shown to other players in lobbies and the active match leaderboard.</p>
                </div>
              </div>

              {/* CREATE LOBBY COMPONENT */}
              <div className="p-8 bg-white border border-slate-100 rounded-3xl shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between gap-6">
                <div>
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 bg-indigo-50 border border-indigo-100 rounded-2xl flex items-center justify-center text-indigo-600">
                      <Plus size={20} />
                    </div>
                    <div>
                      <h2 className="text-lg font-extrabold tracking-tight text-indigo-950 uppercase">Make A Lobby</h2>
                      <p className="text-xs text-slate-400 font-semibold block leading-none">Create room & generate code</p>
                    </div>
                  </div>

                  {/* Lobby creation settings */}
                  <div className="flex flex-col gap-4 pt-4 border-t border-slate-50">
                    <div>
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-2">Grid Size / Pairs</label>
                      <div className="grid grid-cols-3 gap-1 bg-slate-50 border border-slate-100 p-1 rounded-xl">
                        {(['easy', 'medium', 'hard'] as const).map((diffKey) => {
                          const active = difficulty === diffKey;
                          const gridLabel = diffKey === 'easy' ? '3x4' : diffKey === 'hard' ? '4x5' : '4x4';
                          return (
                            <button
                              key={diffKey}
                              onClick={() => setDifficulty(diffKey)}
                              className={`py-1.5 text-[10px] font-bold rounded-lg transition-all cursor-pointer ${
                                active 
                                  ? 'bg-white text-slate-900 shadow-xs border border-slate-200/50' 
                                  : 'text-slate-500 hover:text-slate-900'
                              }`}
                            >
                              {gridLabel}
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    <div>
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-2">Card Theme</label>
                      <div className="grid grid-cols-2 gap-1.5">
                        {(Object.keys(THEMES) as ThemeName[]).map((themeKey) => {
                          const isActive = theme === themeKey;
                          const sampleEmoji = THEMES[themeKey][0].emoji;
                          return (
                            <button
                              key={themeKey}
                              onClick={() => setTheme(themeKey)}
                              className={`px-3 py-1.5 rounded-xl border text-left transition-all cursor-pointer flex items-center justify-between ${
                                isActive 
                                  ? 'bg-indigo-50/50 border-indigo-200 text-indigo-950 font-bold shadow-xs' 
                                  : 'bg-white border-slate-100 text-slate-500 hover:bg-slate-50'
                              }`}
                            >
                              <span className="text-[10px] capitalize">{themeKey}</span>
                              <span className="text-xs">{sampleEmoji}</span>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                </div>

                <button
                  onClick={handleCreateLobby}
                  disabled={isConnecting}
                  className="w-full py-4 bg-indigo-600 text-white rounded-2xl font-bold text-sm shadow-lg shadow-indigo-100 hover:bg-indigo-700 hover:scale-[1.01] active:scale-[0.99] transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 animate-fade-in"
                >
                  {isConnecting ? (
                    <>
                      <Loader2 size={16} className="animate-spin" />
                      <span>Creating Lobby...</span>
                    </>
                  ) : (
                    <>
                      <Plus size={16} />
                      <span>Generate Lobby Master</span>
                    </>
                  )}
                </button>
              </div>

              {/* JOIN LOBBY COMPONENT */}
              <div className="p-8 bg-white border border-slate-100 rounded-3xl shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between gap-6">
                <div>
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 bg-emerald-50 border border-emerald-100 rounded-2xl flex items-center justify-center text-emerald-600">
                      <LogIn size={20} />
                    </div>
                    <div>
                      <h2 className="text-lg font-extrabold tracking-tight text-emerald-950 uppercase">Join A Lobby</h2>
                      <p className="text-xs text-slate-400 font-semibold block leading-none">Enter provide code</p>
                    </div>
                  </div>

                  {/* Room code input */}
                  <div className="flex flex-col gap-4 pt-4 border-t border-slate-50">
                    <div className="flex flex-col gap-2">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Lobby Room Code</label>
                      <input 
                        type="text" 
                        value={joinCodeInput}
                        onChange={(e) => setJoinCodeInput(e.target.value.toUpperCase().slice(0,4))}
                        placeholder="E.G. HJK8"
                        className="w-full tracking-widest text-center py-4 bg-slate-50 border border-slate-200 rounded-2xl text-indigo-950 font-black text-2xl uppercase focus:outline-hidden focus:border-emerald-400 focus:bg-white transition-all placeholder:text-slate-300 placeholder:text-lg placeholder:font-normal"
                        maxLength={4}
                      />
                    </div>
                  </div>
                </div>

                <button
                  onClick={handleJoinLobby}
                  disabled={isConnecting}
                  className="w-full py-4 bg-emerald-600 text-white rounded-2xl font-bold text-sm shadow-lg shadow-emerald-100 hover:bg-emerald-700 hover:scale-[1.01] active:scale-[0.99] transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  {isConnecting ? (
                    <>
                      <Loader2 size={16} className="animate-spin" />
                      <span>Connecting...</span>
                    </>
                  ) : (
                    <>
                      <LogIn size={16} />
                      <span>Enter Lobby Room</span>
                    </>
                  )}
                </button>
              </div>

            </div>
          ) : !lobby.gameStarted ? (
            /* LOBBY ACTIVE SCREEN (WAITING & HOST ADMIN PANEL) */
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 max-w-5xl mx-auto w-full">
              
              {/* Left Column: Lobby Code & Settings */}
              <div className="lg:col-span-5 flex flex-col gap-6">
                
                {/* Lobby Main Info */}
                <div className="p-6 bg-white border border-slate-100 rounded-3xl shadow-sm flex flex-col gap-4">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block leading-none">Room Code</span>
                  <div className="flex items-center justify-between bg-slate-50 border border-slate-100 p-4 rounded-2xl">
                    <span className="text-3xl font-black font-mono tracking-wider text-indigo-950">{lobby.code}</span>
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(lobby.code);
                        setCopiedCode(true);
                        setTimeout(() => setCopiedCode(false), 2000);
                      }}
                      className="px-4 py-2 bg-white hover:bg-slate-100 border border-slate-200 rounded-xl text-xs font-bold text-slate-600 flex items-center gap-1.5 transition-colors cursor-pointer"
                    >
                      {copiedCode ? <Check size={14} className="text-emerald-500" /> : <Copy size={14} />}
                      <span>{copiedCode ? 'Copied' : 'Copy'}</span>
                    </button>
                  </div>

                  <div className="grid grid-cols-2 gap-4 pt-3 border-t border-slate-50 text-xs">
                    <div>
                      <span className="text-slate-400 block font-semibold mb-0.5">Difficulty</span>
                      <span className="font-extrabold text-slate-800 uppercase">{lobby.difficulty === 'easy' ? '3x4 Grid' : lobby.difficulty === 'hard' ? '4x5 Grid' : '4x4 Grid'}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block font-semibold mb-0.5">Theme Selection</span>
                      <span className="font-extrabold text-indigo-600 uppercase flex items-center gap-1">
                        <span>{THEMES[lobby.theme as ThemeName]?.[0]?.emoji}</span>
                        <span>{lobby.theme}</span>
                      </span>
                    </div>
                  </div>

                  <div className="pt-2">
                    <button
                      onClick={handleLeaveLobby}
                      className="w-full py-2.5 bg-slate-50 hover:bg-rose-50 border border-slate-200 hover:border-rose-100 rounded-xl text-xs font-bold text-slate-600 hover:text-rose-600 flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                    >
                      <LogOut size={13} />
                      <span>Leave Lobby</span>
                    </button>
                  </div>
                </div>

                {/* REAL-TIME CHAT PANEL */}
                <div className="p-6 bg-white border border-slate-100 rounded-3xl shadow-sm flex flex-col gap-4 h-80">
                  <div className="flex items-center gap-2">
                    <MessageSquare size={16} className="text-indigo-600" />
                    <span className="text-xs font-extrabold text-slate-800 uppercase tracking-wider">Lobby Chat</span>
                  </div>

                  {/* Scrollable messages box */}
                  <div className="flex-1 overflow-y-auto bg-slate-50/50 border border-slate-100 rounded-2xl p-4 flex flex-col gap-3 min-h-0">
                    {(!lobby.messages || lobby.messages.length === 0) ? (
                      <div className="m-auto text-center text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                        No messages yet. Say hello!
                      </div>
                    ) : (
                      lobby.messages.map((msg: any) => {
                        const isSelf = msg.playerId === playerId;
                        return (
                          <div key={msg.id} className={`flex flex-col max-w-[85%] ${isSelf ? 'self-end items-end' : 'self-start items-start'}`}>
                            <div className="flex items-center gap-1.5 mb-0.5">
                              <span className={`text-[10px] font-bold ${isSelf ? 'text-indigo-600' : 'text-slate-500'}`}>{msg.name}</span>
                              <span className="text-[8px] text-slate-400">{new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                            </div>
                            <div className={`p-2.5 rounded-2xl text-xs leading-normal font-medium ${isSelf ? 'bg-indigo-600 text-white rounded-tr-none' : 'bg-slate-100 text-slate-800 rounded-tl-none'}`}>
                              {msg.text}
                            </div>
                          </div>
                        );
                      })
                    )}
                    <div ref={chatEndRef} />
                  </div>

                  {/* Message Input form */}
                  <form onSubmit={handleSendMessage} className="flex gap-2 shrink-0">
                    <input
                      type="text"
                      value={chatInput}
                      onChange={(e) => setChatInput(e.target.value)}
                      placeholder="Type a message..."
                      className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-medium focus:outline-hidden focus:border-indigo-400 focus:bg-white transition-all text-slate-800"
                      maxLength={100}
                    />
                    <button
                      type="submit"
                      className="p-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl flex items-center justify-center transition-colors cursor-pointer"
                    >
                      <Send size={14} />
                    </button>
                  </form>
                </div>

              </div>

              {/* Right Column: Joined Players & Launch Game */}
              <div className="lg:col-span-7 flex flex-col gap-6">
                
                {/* Players Lobby Membership list */}
                <div className="p-6 bg-white border border-slate-100 rounded-3xl shadow-sm flex flex-col gap-4">
                  <div className="flex justify-between items-center">
                    <span className="text-xs font-extrabold text-slate-800 uppercase tracking-wider block">Joined Players ({lobby.players.length}/10)</span>
                    <span className="px-2.5 py-1 bg-emerald-50 text-emerald-700 rounded-full text-[9px] font-black uppercase tracking-widest flex items-center gap-1 animate-pulse">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                      <span>Gathering</span>
                    </span>
                  </div>

                  <div className="flex flex-col gap-2 pt-2 border-t border-slate-50">
                    {lobby.players.map((p: any) => {
                      const isMe = p.id === playerId;
                      return (
                        <div key={p.id} className={`flex items-center justify-between p-3 rounded-2xl border ${isMe ? 'bg-indigo-50/30 border-indigo-100' : 'bg-slate-50/50 border-slate-100'}`}>
                          <div className="flex items-center gap-3">
                            <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs ${p.isHost ? 'bg-amber-100 text-amber-700 border border-amber-200' : 'bg-slate-200 text-slate-600'}`}>
                              {p.isHost ? <Crown size={14} className="fill-amber-500 text-amber-500" /> : <User size={14} />}
                            </div>
                            <div>
                              <div className="flex items-center gap-1.5">
                                <span className="font-extrabold text-slate-800 text-xs md:text-sm">{p.name}</span>
                                {isMe && <span className="text-[9px] font-black text-indigo-600 uppercase tracking-wider">(Me)</span>}
                              </div>
                              <span className="text-[10px] text-slate-400 font-bold uppercase">{p.isHost ? 'Admin/Lobby Master' : 'Player Participant'}</span>
                            </div>
                          </div>

                          <div className="flex items-center gap-2">
                            <span className={`w-2 h-2 rounded-full ${p.isConnected ? 'bg-emerald-500' : 'bg-rose-400'}`}></span>
                            <span className="text-[10px] font-bold text-slate-500 uppercase">{p.isConnected ? 'Online' : 'Offline'}</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Host Control Actions or Non-host Loader indicator */}
                <div className="p-6 bg-slate-50 border border-slate-100 rounded-3xl flex flex-col gap-4 text-center">
                  {lobby.players.find((p: any) => p.id === playerId)?.isHost ? (
                    <>
                      {lobby.players.length < 2 ? (
                        <>
                          <div className="w-10 h-10 rounded-full bg-amber-50 border border-amber-100 flex items-center justify-center text-amber-600 mx-auto">
                            <Loader2 size={18} className="animate-spin" />
                          </div>
                          <div>
                            <h3 className="text-sm font-extrabold text-slate-900 uppercase">Waiting For Opponent</h3>
                            <p className="text-xs text-slate-400 font-medium mt-1">
                              Share your Room Code <strong className="text-indigo-600 font-mono font-black">{lobby.code}</strong> with a friend. No bots will be automatically added; the lobby will wait here until a real player joins.
                            </p>
                          </div>
                          <button
                            disabled
                            className="w-full py-4 bg-slate-200 text-slate-400 rounded-2xl font-bold text-sm cursor-not-allowed flex items-center justify-center gap-2"
                          >
                            <Users size={16} />
                            <span>Waiting for Player to Join ({lobby.players.length}/2 minimum)</span>
                          </button>
                        </>
                      ) : (
                        <>
                          <div className="w-10 h-10 rounded-full bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600 mx-auto animate-bounce">
                            <Play size={18} className="fill-indigo-600 ml-0.5" />
                          </div>
                          <div>
                            <h3 className="text-sm font-extrabold text-slate-900 uppercase">You Are Lobby Admin</h3>
                            <p className="text-xs text-slate-400 font-medium mt-1">Initiate the real-time board once all participants have entered. Every member's cards grid will sync instantly.</p>
                          </div>
                          <button
                            onClick={handleStartGameMultiplayer}
                            className="w-full py-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl font-bold text-sm shadow-xl shadow-indigo-100 transition-all flex items-center justify-center gap-2 cursor-pointer transform hover:scale-[1.01] active:scale-[0.99] animate-pulse"
                          >
                            <Play size={16} className="fill-white" />
                            <span>Launch Match Board Now</span>
                          </button>
                        </>
                      )}
                    </>
                  ) : (
                    <>
                      <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 mx-auto">
                        <Loader2 size={18} className="animate-spin text-indigo-600" />
                      </div>
                      <div>
                        <h3 className="text-sm font-extrabold text-slate-900 uppercase">Waiting For Lobby Master</h3>
                        <p className="text-xs text-slate-400 font-medium mt-1">The Host is organizing the grid. Hang loose! The game will start automatically when they tap launch.</p>
                      </div>
                    </>
                  )}
                </div>

              </div>

            </div>
          ) : (
            /* ACTIVE MULTIPLAYER GAMEPLAY AND LIVE SCOREBOARD */
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 w-full items-start" id="multiplayer_active_stage">
              
              {/* Left Column: Turn info, Leaderboard & integrated chat */}
              <div className="lg:col-span-4 flex flex-col gap-6 shrink-0">
                
                {/* Active Player turn notification */}
                <div className={`p-5 rounded-3xl border text-center flex flex-col gap-2 ${
                  lobby.activeTurnPlayerId === playerId 
                    ? 'bg-gradient-to-r from-amber-50 to-orange-50 border-amber-200 text-amber-900 shadow-md shadow-amber-50' 
                    : 'bg-white border-slate-100 text-slate-700'
                }`}>
                  <div className="flex justify-center items-center gap-1.5">
                    {lobby.activeTurnPlayerId === playerId ? (
                      <>
                        <span className="flex h-2 w-2 relative">
                          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                          <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-500"></span>
                        </span>
                        <span className="text-xs font-black uppercase tracking-widest text-amber-700">Your Active Turn!</span>
                      </>
                    ) : (
                      <>
                        <Loader2 size={12} className="animate-spin text-indigo-600" />
                        <span className="text-xs font-bold uppercase tracking-widest text-slate-400">Player Turn</span>
                      </>
                    )}
                  </div>
                  <h3 className="text-sm font-black text-slate-800 leading-none">
                    {lobby.activeTurnPlayerId === playerId ? (
                      "FLIP ANY TWO FACE DOWN CARDS"
                    ) : (
                      `${lobby.players.find((p: any) => p.id === lobby.activeTurnPlayerId)?.name || 'Player'}'s Turn...`
                    )}
                  </h3>
                  <div className="text-[10px] text-slate-400 font-bold uppercase mt-1">
                    TIME ELAPSED: <span className="font-mono text-slate-700 font-extrabold">{formatTime(lobby.secondsElapsed || 0)}</span>
                  </div>
                </div>

                {/* Real-time Multiplayer Leaderboard */}
                <div className="p-6 bg-white border border-slate-100 rounded-3xl shadow-sm flex flex-col gap-4">
                  <span className="text-xs font-extrabold text-slate-800 uppercase tracking-wider block border-b border-slate-50 pb-2">Match Standings</span>
                  
                  <div className="flex flex-col gap-2">
                    {[...lobby.players]
                      .sort((a, b) => b.score - a.score)
                      .map((p: any, idx) => {
                        const isMe = p.id === playerId;
                        const isPlayerTurn = lobby.activeTurnPlayerId === p.id;
                        return (
                          <div key={p.id} className={`flex items-center justify-between p-2.5 rounded-xl border ${
                            isPlayerTurn 
                              ? 'bg-amber-50/50 border-amber-200' 
                              : isMe 
                                ? 'bg-indigo-50/10 border-indigo-100' 
                                : 'bg-slate-50/30 border-slate-100/60'
                          }`}>
                            <div className="flex items-center gap-2">
                              <span className="text-[10px] font-bold text-slate-400">#{idx + 1}</span>
                              <div className="relative">
                                <div className={`w-7 h-7 rounded-full flex items-center justify-center font-extrabold text-xs ${
                                  isPlayerTurn ? 'bg-amber-400 text-white' : 'bg-slate-200 text-slate-600'
                                }`}>
                                  {idx === 0 ? <Crown size={12} className="fill-amber-500 text-amber-500" /> : p.name[0].toUpperCase()}
                                </div>
                                {!p.isConnected && (
                                  <span className="absolute -bottom-0.5 -right-0.5 w-2 h-2 rounded-full bg-rose-500 ring-1 ring-white"></span>
                                )}
                              </div>
                              <div>
                                <span className="font-bold text-slate-800 text-xs flex items-center gap-1">
                                  <span>{p.name}</span>
                                  {isMe && <span className="text-[8px] font-black text-indigo-600 uppercase tracking-widest">(Me)</span>}
                                </span>
                                {p.streak > 0 && (
                                  <span className="text-[8px] bg-amber-50 text-amber-700 font-extrabold px-1 rounded flex items-center gap-0.5 w-max">
                                    <Flame size={8} className="fill-amber-500" />
                                    <span>x{p.streak} Streak</span>
                                  </span>
                                )}
                              </div>
                            </div>

                            <span className="font-mono text-xs font-black text-indigo-600">{p.score} pts</span>
                          </div>
                        );
                      })}
                  </div>
                </div>

                {/* Integrated In-Game Chat Box */}
                <div className="p-5 bg-white border border-slate-100 rounded-3xl shadow-sm flex flex-col gap-3 h-52">
                  <div className="overflow-y-auto bg-slate-50/50 border border-slate-100 rounded-xl p-3 flex flex-col gap-2 min-h-0 flex-1">
                    {(lobby.messages || []).slice(-15).map((msg: any) => {
                      const isSelf = msg.playerId === playerId;
                      return (
                        <div key={msg.id} className="text-[10px] font-medium leading-normal">
                          <span className={`font-bold ${isSelf ? 'text-indigo-600' : 'text-slate-500'}`}>{msg.name}: </span>
                          <span className="text-slate-700">{msg.text}</span>
                        </div>
                      );
                    })}
                    <div ref={chatEndRef} />
                  </div>
                  <form onSubmit={handleSendMessage} className="flex gap-2">
                    <input
                      type="text"
                      value={chatInput}
                      onChange={(e) => setChatInput(e.target.value)}
                      placeholder="Taunt or reply..."
                      className="flex-1 bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-[10px] focus:outline-hidden focus:border-indigo-400 focus:bg-white transition-all text-slate-800"
                      maxLength={100}
                    />
                    <button type="submit" className="p-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg cursor-pointer">
                      <Send size={10} />
                    </button>
                  </form>
                </div>

                <button
                  onClick={handleLeaveLobby}
                  className="w-full py-3 bg-slate-100 hover:bg-rose-50 border border-slate-200 hover:border-rose-100 rounded-2xl text-xs font-bold text-slate-500 hover:text-rose-600 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <LogOut size={13} />
                  <span>Exit & Forfeit Match</span>
                </button>

              </div>

              {/* Right Column: Multiplayer Synchronized Card Board Grid */}
              <div className="lg:col-span-8 flex items-center justify-center bg-white rounded-[40px] border border-slate-100 shadow-xl relative min-h-[460px] p-8">
                
                {/* Background Confetti on Win State */}
                <VictoryConfetti active={lobby.gameWon} />

                {/* Victory / Game Won Overlay Panel */}
                {lobby.gameWon && (
                  <div className="absolute inset-0 bg-white/95 backdrop-blur-xs rounded-[40px] z-40 flex flex-col items-center justify-center p-6 text-center animate-fade-in">
                    <div className="w-16 h-16 rounded-full bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-600 shadow-sm mb-4 animate-bounce">
                      <Trophy size={36} className="fill-amber-400 stroke-[2]" />
                    </div>

                    <h2 className="text-3xl font-extrabold tracking-tight text-slate-900 uppercase font-sans italic">
                      Match Finished!
                    </h2>
                    
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mt-1">
                      Winner: <strong className="text-indigo-600 font-extrabold text-sm">{lobby.players.find((p: any) => p.id === lobby.winnerId)?.name || 'Unknown'}</strong>
                    </p>

                    {/* Final Leaderboard Board */}
                    <div className="flex flex-col gap-1.5 max-w-sm w-full my-6 bg-[#F8FAFC] border border-slate-100 p-4 rounded-2xl text-slate-700">
                      <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-1">Final Standings</span>
                      {[...lobby.players]
                        .sort((a, b) => b.score - a.score)
                        .map((p: any, index) => (
                          <div key={p.id} className="flex justify-between items-center bg-white p-2 rounded-xl border border-slate-50 text-xs">
                            <span className="font-bold text-slate-700">#{index+1} {p.name}</span>
                            <span className="font-mono font-bold text-indigo-600">{p.score} pts</span>
                          </div>
                        ))}
                    </div>

                    {/* Host Play Again or Participant wait state */}
                    {lobby.players.find((p: any) => p.id === playerId)?.isHost ? (
                      <button
                        onClick={handleStartGameMultiplayer}
                        className="px-6 py-3.5 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold transition-all shadow-md hover:shadow-lg cursor-pointer flex items-center gap-2 transform active:scale-95 animate-pulse"
                      >
                        <RotateCcw size={16} />
                        <span>Restart New Match</span>
                      </button>
                    ) : (
                      <p className="text-xs text-slate-400 font-semibold uppercase animate-pulse">Waiting for Admin to launch next board...</p>
                    )}
                  </div>
                )}

                {/* Cards grid wrapper */}
                <div className="w-full h-full flex flex-col items-center justify-center">
                  <div 
                    className={`grid gap-4 w-full select-none justify-center ${
                      lobby.difficulty === 'easy' 
                        ? 'grid-cols-3 max-w-md' 
                        : lobby.difficulty === 'hard' 
                          ? 'grid-cols-4 sm:grid-cols-5 max-w-2xl' 
                          : 'grid-cols-4 max-w-xl'
                    } ${
                      (lobby.activeTurnPlayerId !== playerId || lobby.isEvaluating) ? 'pointer-events-none opacity-90' : ''
                    }`}
                  >
                    {(lobby.cards || []).map((card: any, idx: number) => {
                      const isFlipped = card.isFlipped || card.isMatched;
                      return (
                        <div 
                          key={card.id}
                          onClick={() => handleCardClickMultiplayer(idx)}
                          className="aspect-square perspective-1000 cursor-pointer group relative w-full"
                          style={{ minHeight: '80px', minWidth: '80px' }}
                        >
                          <div className={`relative w-full h-full transition-transform duration-500 preserve-3d ${
                            isFlipped ? 'rotate-y-180' : ''
                          }`}>
                            
                            {/* Facedown State */}
                            <div className="absolute inset-0 w-full h-full bg-slate-50 border-2 border-slate-100 rounded-3xl flex items-center justify-center shadow-xs group-hover:border-indigo-200 group-hover:shadow-md transition-all backface-hidden">
                              <div className="w-12 h-12 rounded-full bg-slate-200/50 opacity-25 group-hover:scale-110 transition-transform duration-300" />
                            </div>

                            {/* Flipped/Matched State */}
                            <div className={`absolute inset-0 w-full h-full rounded-3xl border-2 flex flex-col items-center justify-center backface-hidden rotate-y-180 transition-all ${
                              card.isMatched 
                                ? 'bg-emerald-50 border-emerald-500 text-emerald-800 shadow-md relative overflow-hidden' 
                                : `${card.color} text-white shadow-lg`
                            }`}>
                              <span className="text-3xl md:text-4xl filter drop-shadow-xs mb-1 select-none">
                                {card.value}
                              </span>
                              <span className="text-[9px] font-extrabold font-mono uppercase tracking-widest opacity-75 leading-none select-none">
                                {card.label}
                              </span>

                              {card.isMatched && (
                                <div className="absolute top-2 right-2 bg-emerald-500 rounded-full p-0.5">
                                  <svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 20 20">
                                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd"/>
                                  </svg>
                                </div>
                              )}
                            </div>

                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {lobby.activeTurnPlayerId !== playerId && !lobby.gameWon && (
                    <div className="mt-6 text-xs text-slate-400 font-bold uppercase tracking-wider flex items-center gap-1.5 animate-pulse">
                      <Lock size={12} className="text-slate-300" />
                      <span>Viewing opponent turn... Board is locked</span>
                    </div>
                  )}
                </div>

              </div>

            </div>
          )}
        </main>
      )}

      {activeTab === 'history' && (
        /* GAME HISTORY INTERFACE */
        <main className="flex-1 w-full max-w-4xl mx-auto px-6 md:px-12 pb-12 flex flex-col gap-6 animate-fade-in" id="history_main">
          
          {/* Header metadata for future SQL DB connection preview */}
          <div className="p-6 bg-indigo-50/40 border border-indigo-100 rounded-3xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <h2 className="text-sm font-black text-slate-800 uppercase tracking-wider flex items-center gap-2">
                <History size={16} className="text-indigo-600" /> Matches Database Preview
              </h2>
              <p className="text-xs text-slate-500 font-medium mt-1 leading-relaxed">
                Your completed game records are structured in standard SQL schema formats and temporarily saved to <code className="bg-white px-1.5 py-0.5 rounded border text-indigo-600 text-[10px] font-mono">localStorage</code>, ready for integration with PostgreSQL / Cloud SQL!
              </p>
            </div>
            {gameHistory.length > 0 && (
              <button 
                onClick={() => {
                  if (confirm("Are you sure you want to clear your local game history log?")) {
                    setGameHistory([]);
                    localStorage.removeItem('memoryMatch_gameHistory');
                  }
                }}
                className="px-4 py-2 bg-white hover:bg-rose-50 border border-slate-200 hover:border-rose-100 text-slate-500 hover:text-rose-600 text-xs font-bold rounded-xl cursor-pointer transition-colors shrink-0 flex items-center gap-1.5"
              >
                <Trash2 size={12} />
                <span>Reset History Log</span>
              </button>
            )}
          </div>

          {gameHistory.length === 0 ? (
            <div className="p-12 text-center bg-white border border-slate-100 rounded-3xl shadow-xs flex flex-col gap-3 items-center justify-center">
              <div className="w-12 h-12 rounded-full bg-slate-50 border border-slate-100 flex items-center justify-center text-slate-400">
                <History size={20} />
              </div>
              <div>
                <h3 className="text-sm font-extrabold text-slate-800 uppercase">No Matches Found Yet</h3>
                <p className="text-xs text-slate-400 font-medium mt-1">Complete a match in Solo Play or Multiplayer mode to generate standard log entries.</p>
              </div>
            </div>
          ) : (
            <div className="flex flex-col gap-4">
              {gameHistory.map((record) => {
                const dateString = new Date(record.completedAt).toLocaleString();
                const winnerName = record.players.find(p => p.isWinner)?.name || 'N/A';
                
                return (
                  <div key={record.id} className="bg-white border border-slate-100 rounded-3xl p-6 shadow-xs hover:shadow-sm transition-all flex flex-col gap-4">
                    
                    {/* Top stats bar of record */}
                    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-slate-50 pb-3">
                      <div className="flex items-center gap-2.5 flex-wrap">
                        <span className={`px-2.5 py-1 text-[9px] font-black uppercase tracking-wider rounded-lg ${
                          record.mode === 'multiplayer' 
                            ? 'bg-indigo-50 text-indigo-700 border border-indigo-100' 
                            : 'bg-emerald-50 text-emerald-700 border border-emerald-100'
                        }`}>
                          {record.mode}
                        </span>
                        
                        <span className="px-2.5 py-1 bg-slate-50 border border-slate-100 text-slate-500 text-[9px] font-black uppercase tracking-wider rounded-lg">
                          {record.difficulty} Grid
                        </span>

                        <span className="px-2.5 py-1 bg-slate-50 border border-slate-100 text-slate-500 text-[9px] font-black uppercase tracking-wider rounded-lg capitalize">
                          Theme: {record.theme}
                        </span>
                      </div>

                      <div className="flex items-center gap-1.5 text-slate-400 text-[10px] font-bold uppercase font-mono">
                        <Calendar size={12} className="text-slate-300" />
                        <span>{dateString}</span>
                      </div>
                    </div>

                    {/* Middle info content: Duration, Moves, Winner */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 bg-slate-50/50 p-4 rounded-2xl border border-slate-100/30">
                      <div>
                        <span className="text-[10px] text-slate-400 font-bold uppercase block tracking-wider leading-none">Duration</span>
                        <span className="font-mono text-sm font-extrabold text-slate-800 mt-1 block">
                          {formatTime(record.durationSeconds)}
                        </span>
                      </div>
                      
                      {record.mode === 'solo' ? (
                        <div>
                          <span className="text-[10px] text-slate-400 font-bold uppercase block tracking-wider leading-none">Moves Count</span>
                          <span className="font-mono text-sm font-extrabold text-slate-800 mt-1 block">
                            {record.players[0]?.moves || 0}
                          </span>
                        </div>
                      ) : (
                        <div>
                          <span className="text-[10px] text-slate-400 font-bold uppercase block tracking-wider leading-none">Room Size</span>
                          <span className="font-mono text-sm font-extrabold text-slate-800 mt-1 block">
                            {record.players.length} Players
                          </span>
                        </div>
                      )}

                      <div>
                        <span className="text-[10px] text-slate-400 font-bold uppercase block tracking-wider leading-none">Winner</span>
                        <span className="text-sm font-extrabold text-indigo-600 mt-1 block truncate">
                          {winnerName}
                        </span>
                      </div>

                      <div>
                        <span className="text-[10px] text-slate-400 font-bold uppercase block tracking-wider leading-none">Record UID</span>
                        <span className="font-mono text-[9px] font-semibold text-slate-400 mt-1 block truncate" title={record.id}>
                          {record.id}
                        </span>
                      </div>
                    </div>

                    {/* SQL Blueprint structure tooltip */}
                    <div>
                      <span className="text-[10px] text-slate-400 font-black uppercase tracking-widest block mb-2">Participant List</span>
                      <div className="flex flex-col gap-1.5">
                        {record.players.map((player, pIdx) => (
                          <div key={pIdx} className="flex justify-between items-center bg-slate-50/30 border border-slate-100 p-2.5 rounded-xl text-xs">
                            <span className="font-bold text-slate-700 flex items-center gap-1.5">
                              {player.isWinner && <Crown size={12} className="text-amber-500 fill-amber-500" />}
                              <span>{player.name}</span>
                            </span>
                            <span className="font-mono font-extrabold text-indigo-600">{player.score} pts</span>
                          </div>
                        ))}
                      </div>
                    </div>

                  </div>
                );
              })}
            </div>
          )}

        </main>
      )}

      {/* Footer Bar from Theme */}
      <footer className="px-6 md:px-12 py-6 border-t border-slate-100 bg-white flex flex-col sm:flex-row justify-between items-center gap-4 mt-auto" id="app_footer_brand">
        <div className="flex gap-4">
          <span className="px-3 py-1 bg-slate-100 rounded-lg text-[11px] font-bold text-slate-500 uppercase tracking-wider">
            {difficulty === 'easy' ? '3x4 Grid' : difficulty === 'hard' ? '4x5 Grid' : '4x4 Grid'}
          </span>
          <span className="px-3 py-1 bg-slate-100 rounded-lg text-[11px] font-bold text-slate-500 uppercase tracking-wider">
            Theme: {theme}
          </span>
        </div>
        <div className="text-[11px] font-medium text-slate-400">
          System Status: <span className="text-emerald-500 font-bold uppercase">Running</span> • V1.0.42
        </div>
      </footer>

      {/* Rules Information Modal Dialog */}
      {showRules && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs z-50 flex items-center justify-center p-4 animate-fade-in" id="rules_modal_overlay">
          <div className="bg-white rounded-3xl max-w-lg w-full border border-slate-100 p-6 shadow-xl relative flex flex-col gap-4" id="rules_modal">
            
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-lg font-extrabold tracking-tight text-slate-900 uppercase italic flex items-center gap-2">
                <Info size={18} className="text-indigo-600" /> Rules & Scoring Info
              </h3>
              <button 
                onClick={() => setShowRules(false)}
                className="text-slate-400 hover:text-slate-800 p-1.5 hover:bg-slate-50 rounded-xl cursor-pointer transition-colors"
                id="close_rules_button"
              >
                <X size={18} />
              </button>
            </div>

            {/* Modal Body */}
            <div className="flex flex-col gap-4 text-slate-600 text-xs md:text-sm leading-relaxed" id="rules_modal_body">
              <div>
                <p className="font-bold text-slate-800 mb-1">🎮 GAME OBJECTIVE:</p>
                <p>Flip the cards and find the matching pairs of identical items in as few moves and as fast as possible.</p>
              </div>

              <div>
                <p className="font-bold text-slate-800 mb-1">🎲 CORE MECHANICS:</p>
                <ul className="list-disc pl-5 flex flex-col gap-1">
                  <li>Tap a facedown card to flip and reveal its value.</li>
                  <li>Flip another card to see if they match.</li>
                  <li>If the cards match, they stay face up permanently with a green success badge.</li>
                  <li>If they mismatch, they flip back face down automatically after 1 second. You can't flip cards during this delay.</li>
                </ul>
              </div>

              <div>
                <p className="font-bold text-slate-800 mb-1">📊 SCORE & REWARD MATHEMATICS:</p>
                <ul className="list-disc pl-5 flex flex-col gap-1">
                  <li>You begin with a baseline budget of <strong className="text-slate-800">1000 points</strong>.</li>
                  <li>Finding a matching pair yields <strong className="text-emerald-600">+200 points</strong>.</li>
                  <li>Consecutive matches build a <strong className="text-indigo-600">Streak Multiplier</strong>, giving an extra bonus of <strong className="text-indigo-600">50 points</strong> multiplied by your streak!</li>
                  <li>Mismatches incur a penalty of <strong className="text-rose-500">-30 points</strong>.</li>
                  <li>Every second that passes ticks down the score by <strong className="text-rose-400">-1 point</strong>, rewarding speed!</li>
                </ul>
              </div>

              <div>
                <p className="font-bold text-slate-800 mb-1">✨ HIGH SCORES & PERSISTENCE:</p>
                <p>Your fastest times, minimum moves, and best scores are saved automatically inside your browser’s localStorage for each grid size separately!</p>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="border-t border-slate-100 pt-4 flex justify-end">
              <button
                onClick={() => setShowRules(false)}
                className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl transition-all shadow-sm cursor-pointer"
                id="close_rules_bottom_button"
              >
                Got It!
              </button>
            </div>

          </div>
        </div>
      )}

      {/* Reset High Scores Confirmation Modal Dialog */}
      {showConfirmReset && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs z-50 flex items-center justify-center p-4 animate-fade-in" id="reset_confirm_overlay">
          <div className="bg-white rounded-3xl max-w-sm w-full border border-slate-100 p-6 shadow-xl relative flex flex-col gap-4 text-center" id="reset_confirm_modal">
            
            <div className="w-12 h-12 rounded-full bg-rose-50 border border-rose-100 flex items-center justify-center text-rose-500 shadow-sm mx-auto">
              <Trash2 size={20} />
            </div>

            <div>
              <h3 className="text-lg font-extrabold text-slate-900 uppercase">Clear Records?</h3>
              <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">
                This will permanently delete your minimum moves, fastest times, and highest scores for the <strong className="text-slate-800 uppercase font-bold">{difficulty}</strong> size.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-2 mt-2">
              <button
                onClick={() => setShowConfirmReset(false)}
                className="py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-all cursor-pointer"
                id="cancel_reset_button"
              >
                No, Keep
              </button>
              <button
                onClick={handleResetHighScores}
                className="py-2.5 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-xl transition-all shadow-sm cursor-pointer"
                id="confirm_reset_button"
              >
                Yes, Delete
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
