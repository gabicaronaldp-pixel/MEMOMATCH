import sqlite3 from 'sqlite3';
import { open, Database } from 'sqlite';

let db: Database | null = null;

export async function initDb() {
  db = await open({
    filename: './database.sqlite',
    driver: sqlite3.Database
  });

  await db.exec(`
    CREATE TABLE IF NOT EXISTS game_records (
      id TEXT PRIMARY KEY,
      mode TEXT NOT NULL,
      difficulty TEXT NOT NULL,
      theme TEXT NOT NULL,
      duration_seconds INTEGER NOT NULL,
      completed_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS game_players (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      record_id TEXT NOT NULL,
      name TEXT NOT NULL,
      score INTEGER NOT NULL,
      is_winner INTEGER NOT NULL,
      moves INTEGER,
      FOREIGN KEY (record_id) REFERENCES game_records(id) ON DELETE CASCADE
    );
  `);
  console.log('SQLite database initialized successfully.');
}

export async function saveGameRecordToDb(
  id: string,
  mode: string,
  difficulty: string,
  theme: string,
  durationSeconds: number,
  completedAt: string,
  players: { name: string; score: number; isWinner: boolean; moves?: number }[]
) {
  try {
    if (!db) await initDb();
    
    await db!.run(
      `INSERT INTO game_records (id, mode, difficulty, theme, duration_seconds, completed_at) 
       VALUES (?, ?, ?, ?, ?, ?)`,
      [id, mode, difficulty, theme, durationSeconds, completedAt]
    );

    for (const player of players) {
      await db!.run(
        `INSERT INTO game_players (record_id, name, score, is_winner, moves) 
         VALUES (?, ?, ?, ?, ?)`,
        [id, player.name, player.score, player.isWinner ? 1 : 0, player.moves || null]
      );
    }
    console.log(`Saved game record ${id} to SQLite DB.`);
  } catch (err) {
    console.error('Error saving game record to SQLite database:', err);
  }
}

export async function getGameHistoryFromDb() {
  try {
    if (!db) await initDb();
    
    const records = await db!.all(`SELECT * FROM game_records ORDER BY completed_at DESC LIMIT 50`);
    const results = [];
    
    for (const r of records) {
      const players = await db!.all(
        `SELECT name, score, is_winner as isWinner, moves FROM game_players WHERE record_id = ?`,
        [r.id]
      );
      
      results.push({
        id: r.id,
        mode: r.mode,
        difficulty: r.difficulty,
        theme: r.theme,
        durationSeconds: r.duration_seconds,
        completedAt: r.completed_at,
        players: players.map(p => ({
          name: p.name,
          score: p.score,
          isWinner: p.isWinner === 1,
          moves: p.moves || undefined
        }))
      });
    }
    
    return results;
  } catch (err) {
    console.error('Error fetching game history from SQLite database:', err);
    return [];
  }
}
